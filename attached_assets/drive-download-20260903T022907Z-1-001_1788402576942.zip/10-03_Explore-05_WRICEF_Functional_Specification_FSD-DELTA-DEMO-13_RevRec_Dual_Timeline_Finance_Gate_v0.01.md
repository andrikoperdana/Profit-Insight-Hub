# Activate - SPH | WRICEF Functional Specification Document (FSD)

**Document Information**
- **Project Name**: SecureProfit Hub (SPH) Implementation
- **Parent Master FSD**: `10-03_Explore-05_WRICEF_Functional_Specification_FSD_SPH_v0.04.md`
- **Document Identifier**: SPH-FSD-W-DEMO-13
- **WRICEF Title**: Revenue Recognition Dual-Timeline & Finance Gate Engine (PSAK 115 / IFRS 15)
- **WRICEF Type**: Workflow (W) / Enhancement (E) / Interface (I)
- **Phase**: 03 - Explore / 04 - Realize
- **Workstream**: Stream 5 — Milestone Billing & Revenue Recognition
- **Sprint Allocation**: Sprint 3 (8 Story Points)
- **Complexity**: Complex
- **Functional Author**: Antigravity AI (Finance & Accounting Track)
- **Business Process Owner**: Finance Lead & Delivery Lead
- **Version**: v0.01
- **Status**: Draft
- **Date**: 2026-09-02
- **Regulatory Standard**: PSAK 115 / IFRS 15 (Revenue from Contracts with Customers — 5-Step Model)
- **Stakeholder Grounding**: Handover from Concept Clarification Meeting (1 Sep 2026)

---

## 1. Business Requirement & Objective

- **Business Need**: In enterprise consulting engagements, billing milestones (Terms of Payment / Cash Flow) and revenue recognition schedules (PSAK 115 / IFRS 15 Accrual Revenue) operate on distinct timelines. The legacy codebase coupled both concepts inside a single `BillingMilestone` model, creating audit compliance gaps and preventing independent revenue recognition against milestone deliverable acceptance.
- **User Story**: *As a Finance Lead & Project Manager, I want a dual-timeline architecture decoupling commercial invoicing from revenue recognition schedules, so that PSAK 115 accrual revenue is recognized strictly upon deliverable verification with independent Finance sign-off.*
- **Trigger Event**: Project activation upon Won contract conversion, or PM evidence submission for revenue milestone recognition.

---

## 2. Immediate Operational & System Effect Post-Implementation

> [!IMPORTANT]
> **Developer Goal & Operational Target**:
> Decouples the commercial invoicing timeline (Terms of Payment) from the revenue recognition timeline (PSAK 115), creating a dedicated `RevenueRecognitionSchedule` model with Finance baseline gating, PM evidence submission, Separation of Duties (SoD), and Xero manual journal CSV exports.

### Immediate Effects:
1. **Dual Timeline Separation**: Invoicing (DPP + PPN 11%) and RevRec (PSAK 115 accrual) are tracked independently without interference.
2. **Finance-Initiated Baseline**: Only `FINANCE` users can create and lock initial RevRec schedule rows at project inception.
3. **Dual Trigger Support**: Supports `FIXED_TERM` (contract date/PO receipt) and `DELIVERY_BASED` (deliverable reports, BAST, acceptance letters).
4. **Strict Separation of Duties (SoD)**: PMs cannot self-approve revenue recognition or unilaterally shift recognition dates.
5. **Xero Accounting Export**: Generates monthly manual journal CSVs mapping Unbilled Receivables (Debit) and Fee Revenue (Credit).

---

## 3. Approved Baseline Decisions & Implementation Invariants

```mermaid
flowchart TD
    subgraph INCEPTION["1. Project Inception & Baseline Locking"]
        Fin["Finance Lead"] -->|1. Creates RevRec Baseline| Sched["RevenueRecognitionSchedule (Status: PLANNED)"]
        Sched -->|2. Defines Triggers| Trig["FIXED_TERM (PO / Advance) OR DELIVERY_BASED (Milestones)"]
    end

    subgraph EXECUTION["2. Delivery & Evidence Submission"]
        PM["Project Manager"] -->|3. Uploads Evidence (BAST / Report PDF)| Upload["POST /api/revrec-schedules/:id/evidence"]
        Upload -->|4. Transitions Status| Pend["Status: PENDING_FINANCE_APPROVAL"]
    end

    subgraph FINANCE_GATE["3. Finance Verification & Gating"]
        Pend --> FinReview{"Finance Lead Audit Review"}
        FinReview -- Approved --> Recog["Status: RECOGNIZED (recognizedDpp Stamped)"]
        FinReview -- Rejected --> Rej["Status: REJECTED (rejectionReason Logged)"]
    end

    subgraph ACCOUNTING["4. Financial Integration"]
        Recog --> XeroExport["Export Monthly PSAK 115 Journal CSV for Xero"]
    end
```

### Core Business Rules:
1. **Initial Creation Authority**: Only users with the `FINANCE` or `FINANCE_LEAD` role can create and lock `RevenueRecognitionSchedule` records during project activation.
2. **Delivery Evidence Requirement**: For `DELIVERY_BASED` items, PM must attach deliverable evidence (`evidenceDocId` referencing `Document` or `reportUrl`) before advancing to `PENDING_FINANCE_APPROVAL`.
3. **Date Shift Governance**: If a project delivery delay occurs, PM can request a schedule date shift, but the record enters `PENDING_FINANCE_APPROVAL` and cannot update `plannedDate` until approved by Finance.
4. **Recognition Lock**: Once marked `RECOGNIZED`, the record is immutable and locked against edits.

---

## 4. Target Data Model Specification (`schema.prisma`)

```prisma
enum RevRecTriggerType {
  FIXED_TERM       // Recognized upon contract date / PO receipt (advance payment)
  DELIVERY_BASED   // Recognized upon milestone delivery, BAST, or report acceptance
}

enum RevRecScheduleStatus {
  PLANNED                   // Baseline locked by Finance at project inception
  PENDING_FINANCE_APPROVAL  // Evidence uploaded or reschedule requested by PM
  RECOGNIZED                // Formally recognized and signed off by Finance
  REJECTED                  // Evidence returned by Finance with note
  CANCELLED                 // Scope descheduled via Change Request
}

model RevenueRecognitionSchedule {
  id                 String                @id @default(cuid())
  projectId          String
  project            Project               @relation(fields: [projectId], references: [id], onDelete: Cascade)
  workstreamId       String?
  workstream         ProjectWorkstream?    @relation(fields: [workstreamId], references: [id], onDelete: SetNull)
  name               String
  description        String?               @db.Text
  triggerType        RevRecTriggerType     @default(DELIVERY_BASED)
  status             RevRecScheduleStatus  @default(PLANNED)
  percentage         Decimal               @db.Decimal(5, 2)
  plannedDpp         Decimal               @db.Decimal(15, 2)
  plannedGross       Decimal               @db.Decimal(15, 2)
  plannedDate        DateTime
  actualDate         DateTime?
  recognizedDpp      Decimal?              @db.Decimal(15, 2)
  evidenceDocId      String?
  evidenceDoc        Document?             @relation(fields: [evidenceDocId], references: [id], onDelete: SetNull)
  reportUrl          String?               @db.Text
  deliverableNotes   String?               @db.Text
  createdById        String
  createdBy          User                  @relation("RevRecScheduleCreator", fields: [createdById], references: [id])
  approvedById       String?
  approvedBy         User?                 @relation("RevRecScheduleApprover", fields: [approvedById], references: [id])
  approvedAt         DateTime?
  rejectionReason    String?               @db.Text
  billingMilestoneId String?
  billingMilestone   BillingMilestone?     @relation(fields: [billingMilestoneId], references: [id], onDelete: SetNull)
  sortOrder          Int                   @default(0)
  createdAt          DateTime              @default(now())
  updatedAt          DateTime              @updatedAt

  @@index([projectId, status])
  @@index([plannedDate])
  @@index([triggerType])
}
```

---

## 5. API Endpoint Specifications

### 5.1 Create RevRec Schedule Baseline
- **Endpoint**: `POST /api/projects/:id/revrec-schedules`
- **RBAC Guard**: `requireRole(['FINANCE', 'FINANCE_LEAD', 'SITE_ADMIN'])`
- **Request Body**:
  ```json
  {
    "schedules": [
      {
        "name": "Initial Discovery Report Delivery",
        "triggerType": "DELIVERY_BASED",
        "percentage": 30.00,
        "plannedDpp": 150000000,
        "plannedGross": 166500000,
        "plannedDate": "2026-10-15T00:00:00Z"
      }
    ]
  }
  ```

### 5.2 Submit Deliverable Evidence
- **Endpoint**: `POST /api/revrec-schedules/:id/evidence`
- **RBAC Guard**: `requireRole(['PROJECT_MANAGER', 'DELIVERY_LEAD', 'SITE_ADMIN'])`
- **Request Body**:
  ```json
  {
    "evidenceDocId": "doc_bast_q3_01",
    "deliverableNotes": "Final Discovery Assessment Report accepted by Client Lead.",
    "actualDate": "2026-10-14T00:00:00Z"
  }
  ```

### 5.3 Finance Approval Gate
- **Endpoint**: `POST /api/revrec-schedules/:id/approve`
- **RBAC Guard**: `requireRole(['FINANCE', 'FINANCE_LEAD', 'SITE_ADMIN'])`
- **Processing**:
  - Validates `status == 'PENDING_FINANCE_APPROVAL'`.
  - Sets `status = 'RECOGNIZED'`, `recognizedDpp = plannedDpp`, `approvedById = req.user.id`, `approvedAt = new Date()`.

---

## 6. Test Scenarios & Acceptance Criteria

| Test Case ID | Test Scenario | Input Data | Expected Result | Pass / Fail |
| :---: | :--- | :--- | :--- | :---: |
| **TC-DEMO-13-01** | Finance creates RevRec schedule baseline | Finance user posts 3 schedule rows | Baseline created with `status = PLANNED` | [ ] |
| **TC-DEMO-13-02** | PM attempts baseline creation | PM user posts to `/api/projects/:id/revrec-schedules` | Blocked with `HTTP 403 Forbidden` | [ ] |
| **TC-DEMO-13-03** | PM submits deliverable evidence | PM attaches BAST document ID | Status transitions to `PENDING_FINANCE_APPROVAL` | [ ] |
| **TC-DEMO-13-04** | PM attempts self-approval | PM posts to `/api/revrec-schedules/:id/approve` | Blocked with `HTTP 403 Forbidden` (SoD Rule) | [ ] |
| **TC-DEMO-13-05** | Finance signs off recognition | Finance Lead approves schedule | Status set to `RECOGNIZED`; ledger updated | [ ] |
| **TC-DEMO-13-06** | Export Xero Journal CSV | Finance clicks Export Monthly Journal | CSV generated with Debit (Unbilled AR) & Credit (Revenue) | [ ] |

---

## 7. Sign-off and Approvals

| Stakeholder Role | Name & Title | Signature | Date | Status |
| :--- | :--- | :--- | :---: | :---: |
| **Finance Process Owner** | | ____________________ | YYYY-MM-DD | Draft |
| **Delivery Process Owner** | | ____________________ | YYYY-MM-DD | Draft |
| **Lead Technical Architect** | | ____________________ | YYYY-MM-DD | Draft |

---

## 8. Document Revision History

| Version | Date | Author / Role | Summary of Changes |
| :---: | :---: | :--- | :--- |
| `v0.01` | 2026-09-02 | Antigravity AI (Finance Track) | Initial functional specification creation for DELTA-DEMO-13 (Revenue Recognition Dual-Timeline & Finance Gate Engine under PSAK 115 / IFRS 15). |
