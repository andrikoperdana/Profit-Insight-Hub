# Activate - SPH | WRICEF Functional Specification Document (FSD)

**Document Information**
- **Project Name**: SecureProfit Hub (SPH) Implementation
- **Parent Master FSD**: `10-03_Explore-05_WRICEF_Functional_Specification_FSD_SPH_v0.03.md`
- **Document Identifier**: SPH-FSD-E-DEMO-12
- **WRICEF Title**: Client Name Immutability Lock Guard
- **WRICEF Type**: Enhancement (E) / Governance
- **Phase**: 03 - Explore / 04 - Realize
- **Workstream**: PMO Governance & Audit Compliance
- **Sprint Allocation**: Sprint 2 (3 Story Points)
- **Complexity**: Simple (Phase 1) / Medium (Phase 2)
- **Functional Author**: Antigravity AI (PMO & Audit Track)
- **Business Process Owner**: PMO Lead & Finance Lead
- **Version**: v0.03
- **Status**: Draft (Decision Baseline Synchronized)
- **Date**: 2026-09-02
- **Decision Grounding**: Decision 12.1 (`Answer to - SecureProfit-Hub-Master-Recommendation-All-12-FSD-ID-2026-08.md v1.00`)

---

## 1. Business Requirement & Objective
- **Business Need**: To ensure audit compliance with tax invoices, BAST sign-offs, and legal contracts, client attribution on delivery projects (`Project.clientId`) must be locked against accidental edits post-creation.
- **User Story**: *As a PMO & Finance Lead, I want client attribution locked on active projects, with exceptional reassignments governed by a dual-approval workflow.*

---

## 2. Immediate Operational & System Effect Post-Implementation

> [!IMPORTANT]
> **Developer Goal & Operational Target**:
> Protects legal contract attribution and tax invoice integrity by enforcing Phase 1 hard locks in the existing codebase and specifying Phase 2 dual-approval correction governance.

### Immediate Effects:
1. **Phase 1 Hard Lock (Verified in `c7080af`)**: Disables client field in UI and returns `HTTP 409 Conflict` (`CLIENT_ATTRIBUTION_LOCKED`) on unauthorized `PUT /api/projects/:id` modifications.
2. **Phase 2 Dual-Approval Correction**: Introduces `ClientAttributionCorrection` state machine requiring dual approval from `MANAGEMENT` and `FINANCE_LEAD` for legal entity corrections.

---

## 3. Approved Baseline Decisions & Implementation Invariants

* **Decision 12.1 `[APPROVED]`**: Phase 1 (Built in `c7080af`): Enforce a hard immutable lock on `Project.clientId` post-creation, returning `HTTP 409 Conflict` (`CLIENT_ATTRIBUTION_LOCKED`) on unauthorized modification attempts. Phase 2 (Target Design): Introduce a formal `ClientAttributionCorrection` governance state machine requiring dual approval from `MANAGEMENT` and `FINANCE_LEAD` for exceptional legal client reassignments.

---

## 4. Phase 2 Target Governance Model

```prisma
model ClientAttributionCorrection {
  id              String    @id @default(cuid())
  projectId       String
  project         Project   @relation(fields: [projectId], references: [id], onDelete: Cascade)
  originalClientId String
  targetClientId  String
  targetClient    Client    @relation(fields: [targetClientId], references: [id])
  justification   String
  status          String    @default("PENDING_APPROVAL") // PENDING_APPROVAL, APPROVED, REJECTED
  requestedById   String
  managementApprId String?
  financeApprId   String?
  executedAt      DateTime?
  createdAt       DateTime  @default(now())
}
```

---

## 5. Test Scenarios & Acceptance Criteria

| Test Case ID | Test Scenario | Expected Result | Pass / Fail |
| :---: | :--- | :--- | :---: |
| **TC-DEMO-12-01** | Modify `clientId` on project via standard PUT | Blocked with `HTTP 409 Conflict` (`CLIENT_ATTRIBUTION_LOCKED`) | [ ] |
| **TC-DEMO-12-02** | Submit Phase 2 correction request | Creates `ClientAttributionCorrection` record in `PENDING_APPROVAL` | [ ] |
| **TC-DEMO-12-03** | Dual approval by Management + Finance | Reassignment executed; audit event recorded | [ ] |

---

## 6. Sign-off and Approvals

| Stakeholder Role | Name & Title | Signature | Date |
| :--- | :--- | :--- | :--- |
| **PMO Process Owner** | | ____________________ | YYYY-MM-DD |
| **Finance Process Owner** | | ____________________ | YYYY-MM-DD |
| **Lead Technical Architect** | | ____________________ | YYYY-MM-DD |

---

## 7. Document Revision History

| Version | Date | Author / Role | Summary of Changes |
| :---: | :---: | :--- | :--- |
| `v0.01` | 2026-08-28 | Antigravity AI | Initial functional specification creation. |
| `v0.02` | 2026-08-28 | Antigravity AI | Added Section 2: Immediate Operational Effect Post-Implementation. |
| `v0.03` | 2026-09-02 | Antigravity AI | **Baseline v1.00 Synchronization**: Incorporated Decision 12.1 (documented Phase 1 Codebase Hard Lock in `c7080af` returning `HTTP 409 Conflict` `CLIENT_ATTRIBUTION_LOCKED`, and specified Phase 2 `ClientAttributionCorrection` dual-approval state machine). |
