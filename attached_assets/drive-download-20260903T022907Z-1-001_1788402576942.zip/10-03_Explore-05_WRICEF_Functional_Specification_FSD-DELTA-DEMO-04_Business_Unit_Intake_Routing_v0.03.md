# Activate - SPH | WRICEF Functional Specification Document (FSD)

**Document Information**
- **Project Name**: SecureProfit Hub (SPH) Implementation
- **Parent Master FSD**: `10-03_Explore-05_WRICEF_Functional_Specification_FSD_SPH_v0.03.md`
- **Document Identifier**: SPH-FSD-W-DEMO-04
- **WRICEF Title**: Business Unit & Workstream Intake Routing
- **WRICEF Type**: Workflow (W) / Enhancement (E)
- **Phase**: 03 - Explore / 04 - Realize
- **Workstream**: Commercial Intake & Governance
- **Sprint Allocation**: Sprint 1 (3 Story Points)
- **Complexity**: Medium
- **Functional Author**: Antigravity AI (Commercial Track)
- **Business Process Owner**: Commercial Lead & Delivery Lead
- **Version**: v0.03
- **Status**: Draft (Decision Baseline Synchronized)
- **Date**: 2026-09-02
- **Decision Grounding**: Decision 4.1 (`Answer to - SecureProfit-Hub-Master-Recommendation-All-12-FSD-ID-2026-08.md v1.00`)

---

## 1. Business Requirement & Objective
- **Business Need**: Opportunities must route to the appropriate Practice Principal (Business Unit Lead) for presales staffing and commercial review, while supporting secondary supporting BUs for multi-practice engagements.
- **User Story**: *As a Commercial Operations Lead, I want leads assigned to a Primary Business Unit with secondary supporting BUs, so that Practice Principals receive immediate qualification alerts.*

---

## 2. Immediate Operational & System Effect Post-Implementation

> [!IMPORTANT]
> **Developer Goal & Operational Target**:
> Establishes clear revenue attribution and automated Principal routing while supporting complex cross-functional practice delivery.

### Immediate Effects:
1. **Single Primary BU Ownership**: Guarantees single-source revenue attribution (`Lead.businessUnitId`).
2. **Normalized Supporting BUs**: Captures secondary practice contributions in `LeadSupportingBusinessUnit`.
3. **Management Fallback Routing**: Automatically redirects routing notifications to `MANAGEMENT` if a BU has no assigned Practice Principal.

---

## 3. Approved Baseline Decisions & Implementation Invariants

* **Decision 4.1 `[APPROVED]`**: Structure organizational assignment with exactly one **Primary BU** (`Lead.businessUnitId`) for revenue attribution and one or more **Supporting BUs** via a normalized `LeadSupportingBusinessUnit` junction table. Auto-route notifications to the Practice Principal of the Primary BU, with automatic fallback routing to `MANAGEMENT` if unassigned.

---

## 4. Target Data Model & Routing Architecture

```prisma
model LeadSupportingBusinessUnit {
  id              String       @id @default(cuid())
  leadId          String
  lead            Lead         @relation(fields: [leadId], references: [id], onDelete: Cascade)
  businessUnitId  String
  businessUnit    BusinessUnit @relation(fields: [businessUnitId], references: [id])
  remarks         String?

  @@unique([leadId, businessUnitId])
}
```

---

## 5. Test Scenarios & Acceptance Criteria

| Test Case ID | Test Scenario | Expected Result | Pass / Fail |
| :---: | :--- | :--- | :---: |
| **TC-DEMO-04-01** | Assign Primary BU | Notification dispatched to Practice Principal of selected BU | [ ] |
| **TC-DEMO-04-02** | Add Supporting BUs | Junction records created; secondary leads receive info copy | [ ] |
| **TC-DEMO-04-03** | BU Principal unassigned | Notification falls back to `MANAGEMENT` distribution list | [ ] |

---

## 6. Sign-off and Approvals

| Stakeholder Role | Name & Title | Signature | Date |
| :--- | :--- | :--- | :--- |
| **Commercial Process Owner** | | ____________________ | YYYY-MM-DD |
| **Delivery Process Owner** | | ____________________ | YYYY-MM-DD |

---

## 7. Document Revision History

| Version | Date | Author / Role | Summary of Changes |
| :---: | :---: | :--- | :--- |
| `v0.01` | 2026-08-28 | Antigravity AI | Initial functional specification creation. |
| `v0.02` | 2026-08-28 | Antigravity AI | Added Section 2: Immediate Operational Effect Post-Implementation. |
| `v0.03` | 2026-09-02 | Antigravity AI | **Baseline v1.00 Synchronization**: Incorporated Decision 4.1 (single Primary BU attribution, `LeadSupportingBusinessUnit` junction table, and `MANAGEMENT` fallback notification routing). |
