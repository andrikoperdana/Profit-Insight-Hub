# Activate - SPH | WRICEF Functional Specification Document (FSD)

**Document Information**
- **Project Name**: SecureProfit Hub (SPH) Implementation
- **Parent Master FSD**: `10-03_Explore-05_WRICEF_Functional_Specification_FSD_SPH_v0.03.md`
- **Document Identifier**: SPH-FSD-E-DEMO-02
- **WRICEF Title**: Structured Products & Services Details Specification
- **WRICEF Type**: Enhancement (E)
- **Phase**: 03 - Explore / 04 - Realize
- **Workstream**: Commercial Intake & Scoping
- **Sprint Allocation**: Sprint 1 (3 Story Points)
- **Complexity**: Medium
- **Functional Author**: Antigravity AI (Commercial Track)
- **Business Process Owner**: Commercial Lead
- **Version**: v0.03
- **Status**: Draft (Decision Baseline Synchronized)
- **Date**: 2026-09-02
- **Decision Grounding**: Decision 2.1, 2.2 (`Answer to - SecureProfit-Hub-Master-Recommendation-All-12-FSD-ID-2026-08.md v1.00`)

---

## 1. Business Requirement & Objective
- **Business Need**: In proposals and deals, commercial scope is often described as free-text remarks, leading to ambiguous deliverables and difficult resource allocation upon project handover.
- **User Story**: *As a Sales AE / Solution Architect, I want to select structured offering line items and snapshot unit prices, so that commercial deliverables automatically map to delivery workstreams.*
- **Trigger Event**: User configures products/services in the Lead form.

---

## 2. Immediate Operational & System Effect Post-Implementation

> [!IMPORTANT]
> **Developer Goal & Operational Target**:
> Eliminates unstructured scope ambiguity by binding lead offerings to master service catalog items with point-in-time price snapshots and automated downstream WBS generation.

### Immediate Effects:
1. **Immutable Scoping Snapshots**: Protects commercial deal margins from retroactive master catalog price changes.
2. **Automated WBS Generation**: Automatically generates initial `ProjectWorkstream` and task templates upon Won project conversion.

---

## 3. Approved Baseline Decisions & Implementation Invariants

* **Decision 2.1 `[APPROVED]`**: Structure products/services as child line items (`LeadOffering`) referencing an `OfferingCatalog`. Snapshot unit price and description at creation (`unitPriceAtSnapshot`) to protect historical records from catalog price adjustments. Allow custom line items with `isCustom: true`.
* **Decision 2.2 `[APPROVED]`**: When a lead converts to an active delivery project, automatically spawn corresponding `ProjectWorkstream` records and pre-populate WBS task templates based on the approved `LeadOffering` line items.

---

## 4. Functional Architecture & Data Model

```mermaid
flowchart TD
    Catalog["OfferingCatalog Master"] -->|Select Offerings| LeadOff["LeadOffering (unitPriceAtSnapshot)"]
    LeadOff -->|On Project Won Conversion| Workstream["ProjectWorkstream & TaskTemplate WBS"]
```

### Prisma Schema (Target Extension):
```prisma
model OfferingCatalog {
  id          String         @id @default(cuid())
  code        String         @unique
  name        String
  category    String
  basePrice   Decimal        @db.Decimal(15, 2)
  isActive    Boolean        @default(true)
  offerings   LeadOffering[]
}

model LeadOffering {
  id                  String           @id @default(cuid())
  leadId              String
  lead                Lead             @relation(fields: [leadId], references: [id], onDelete: Cascade)
  offeringCatalogId   String?
  offeringCatalog     OfferingCatalog? @relation(fields: [offeringCatalogId], references: [id])
  customName          String?
  unitPriceAtSnapshot Decimal          @db.Decimal(15, 2)
  quantity            Int              @default(1)
  isCustom            Boolean          @default(false)
}
```

---

## 5. Test Scenarios & Acceptance Criteria

| Test Case ID | Test Scenario | Expected Result | Pass / Fail |
| :---: | :--- | :--- | :---: |
| **TC-DEMO-02-01** | Add catalog offering | `unitPriceAtSnapshot` copied from `OfferingCatalog.basePrice` | [ ] |
| **TC-DEMO-02-02** | Master catalog price change | Existing `LeadOffering.unitPriceAtSnapshot` remains unchanged | [ ] |
| **TC-DEMO-02-03** | Project conversion WBS spawn | Spawns `ProjectWorkstream` matching active offerings | [ ] |

---

## 6. Sign-off and Approvals

| Stakeholder Role | Name & Title | Signature | Date |
| :--- | :--- | :--- | :--- |
| **Commercial Process Owner** | | ____________________ | YYYY-MM-DD |
| **Lead Technical Architect** | | ____________________ | YYYY-MM-DD |

---

## 7. Document Revision History

| Version | Date | Author / Role | Summary of Changes |
| :---: | :---: | :--- | :--- |
| `v0.01` | 2026-08-28 | Antigravity AI | Initial functional specification creation. |
| `v0.02` | 2026-08-28 | Antigravity AI | Added Section 2: Immediate Operational Effect Post-Implementation. |
| `v0.03` | 2026-09-02 | Antigravity AI | **Baseline v1.00 Synchronization**: Incorporated Decisions 2.1 & 2.2 (`LeadOffering` immutable pricing snapshot and auto-generation of `ProjectWorkstream` on project conversion). |
