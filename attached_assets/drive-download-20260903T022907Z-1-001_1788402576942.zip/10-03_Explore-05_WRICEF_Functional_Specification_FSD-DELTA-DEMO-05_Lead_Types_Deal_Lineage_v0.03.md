# Activate - SPH | WRICEF Functional Specification Document (FSD)

**Document Information**
- **Project Name**: SecureProfit Hub (SPH) Implementation
- **Parent Master FSD**: `10-03_Explore-05_WRICEF_Functional_Specification_FSD_SPH_v0.03.md`
- **Document Identifier**: SPH-FSD-E-DEMO-05
- **WRICEF Title**: Lead Types (Renewal, Up-Sell, Cross-Sell) & Deal Lineage
- **WRICEF Type**: Enhancement (E)
- **Phase**: 03 - Explore / 04 - Realize
- **Workstream**: Commercial Intake & Pipeline Analytics
- **Sprint Allocation**: Sprint 1 (5 Story Points)
- **Complexity**: Medium
- **Functional Author**: Antigravity AI (Commercial Track)
- **Business Process Owner**: Commercial Lead
- **Version**: v0.03
- **Status**: Draft (Decision Baseline Synchronized)
- **Date**: 2026-09-02
- **Decision Grounding**: Decision 5.1 (`Answer to - SecureProfit-Hub-Master-Recommendation-All-12-FSD-ID-2026-08.md v1.00`)

---

## 1. Business Requirement & Objective
- **Business Need**: To track Net Retention Revenue (NRR), renewals, and expansion revenue, leads must be classified by type (`NEW_LOGO`, `RENEWAL`, `UP_SELL`, `CROSS_SELL`, `MAINTENANCE`) and anchored to historical delivery projects.
- **User Story**: *As an Executive / Sales Director, I want leads linked to previous delivery projects, so that NRR and customer lifetime expansion can be tracked accurately.*

---

## 2. Immediate Operational & System Effect Post-Implementation

> [!IMPORTANT]
> **Developer Goal & Operational Target**:
> Provides structured deal taxonomy and rigorous lineage anchoring for enterprise Net Retention Revenue (NRR) calculation.

### Immediate Effects:
1. **Audited Deal Taxonomy**: Distinguishes new client acquisition from recurring/expansion revenue streams.
2. **Project-Only Anchor Invariant**: Prevents linking expansion deals to un-won/cancelled leads.
3. **Cohort ARR NRR Analytics**: Fuels portfolio NRR reports with verified expansion data.

---

## 3. Approved Baseline Decisions & Implementation Invariants

* **Decision 5.1 `[APPROVED]`**: Enforce strict deal lineage. For `RENEWAL`, `UP_SELL`, and `CROSS_SELL` leads, restrict parent linkage strictly to existing, approved `Project` entities (not un-won leads). Calculate Net Retention Revenue (NRR) using the cohort ARR expansion formula: $\text{NRR} = \frac{\text{Ending ARR} + \text{Expansion} - \text{Contraction} - \text{Churn}}{\text{Starting ARR}} \times 100\%$.

---

## 4. Target Data Model & Taxonomy

```prisma
enum LeadType {
  NEW_LOGO
  RENEWAL
  UP_SELL
  CROSS_SELL
  MAINTENANCE
}

model Lead {
  id              String    @id @default(cuid())
  leadType        LeadType  @default(NEW_LOGO)
  parentProjectId String?
  parentProject   Project?  @relation("ProjectLineage", fields: [parentProjectId], references: [id])
}
```

---

## 5. Test Scenarios & Acceptance Criteria

| Test Case ID | Test Scenario | Expected Result | Pass / Fail |
| :---: | :--- | :--- | :---: |
| **TC-DEMO-05-01** | Create `RENEWAL` lead | Requires valid `parentProjectId`; displays project badge | [ ] |
| **TC-DEMO-05-02** | Attempt invalid parent lead link | System restricts parent selector strictly to approved `Project` records | [ ] |
| **TC-DEMO-05-03** | Cohort NRR aggregation | Accurately calculates expansion vs starting ARR | [ ] |

---

## 6. Sign-off and Approvals

| Stakeholder Role | Name & Title | Signature | Date |
| :--- | :--- | :--- | :--- |
| **Commercial Process Owner** | | ____________________ | YYYY-MM-DD |
| **Lead Technical Architect** | | ____________________ | YYYY-MM-DD |

---

## 7. Document Revision History

| Version | Date | Author / Role | Summary of Changes |
| :---: | :---: | :--- | :--- |
| `v0.01` | 2026-08-28 | Antigravity AI | Initial functional specification creation. |
| `v0.02` | 2026-08-28 | Antigravity AI | Added Section 2: Immediate Operational Effect Post-Implementation. |
| `v0.03` | 2026-09-02 | Antigravity AI | **Baseline v1.00 Synchronization**: Incorporated Decision 5.1 (LeadType taxonomy, strict `Project`-only parent anchor invariant, and cohort ARR NRR formulation). |
