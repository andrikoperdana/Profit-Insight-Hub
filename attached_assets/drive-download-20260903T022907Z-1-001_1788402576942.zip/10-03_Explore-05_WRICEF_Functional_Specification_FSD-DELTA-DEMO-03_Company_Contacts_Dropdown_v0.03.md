# Activate - SPH | WRICEF Functional Specification Document (FSD)

**Document Information**
- **Project Name**: SecureProfit Hub (SPH) Implementation
- **Parent Master FSD**: `10-03_Explore-05_WRICEF_Functional_Specification_FSD_SPH_v0.03.md`
- **Document Identifier**: SPH-FSD-E-DEMO-03
- **WRICEF Title**: Company-Originated Contact Dynamic Dropdown & Intake
- **WRICEF Type**: Enhancement (E)
- **Phase**: 03 - Explore / 04 - Realize
- **Workstream**: Commercial Intake & CRM
- **Sprint Allocation**: Sprint 1 (5 Story Points)
- **Complexity**: Medium
- **Functional Author**: Antigravity AI (Commercial Track)
- **Business Process Owner**: Commercial Lead
- **Version**: v0.03
- **Status**: Draft (Decision Baseline Synchronized)
- **Date**: 2026-09-02
- **Decision Grounding**: Decision 3.1 (`Answer to - SecureProfit-Hub-Master-Recommendation-All-12-FSD-ID-2026-08.md v1.00`)

---

## 1. Business Requirement & Objective
- **Business Need**: In enterprise sales, selecting a client company must dynamically filter the associated client contacts (`ClientContact`), preventing cross-company contact mismatches while capturing point-in-time snapshots for audit trails.
- **User Story**: *As a Sales AE, I want the contact dropdown to dynamically filter contacts for the selected client, so that communications are routed to verified client personnel.*
- **Trigger Event**: User selects or changes the Client dropdown in the Lead form.

---

## 2. Immediate Operational & System Effect Post-Implementation

> [!IMPORTANT]
> **Developer Goal & Operational Target**:
> Eliminates contact association errors by dynamically binding contact dropdowns to the active client and snapshotting contact details directly on the lead record.

### Immediate Effects:
1. **Dynamic Client-Filtered Contacts**: Automatically queries `GET /api/clients/:id/contacts` upon client selection.
2. **Point-in-Time Contact Snapshot**: Persists contact details (`contactNameSnapshot`, `contactEmailSnapshot`, `contactPhoneSnapshot`) on the `Lead` model to preserve history if client contacts are edited later.
3. **Legacy Fallback Compatibility**: Preserves scalar contact strings for unstructured external inbound leads.

---

## 3. Approved Baseline Decisions & Implementation Invariants

* **Decision 3.1 `[APPROVED]`**: Bind lead contacts dynamically to the selected client company via `ClientContact` relations. Capture a point-in-time contact snapshot (`contactNameSnapshot`, `contactEmailSnapshot`, `contactPhoneSnapshot`) on `Lead` creation to maintain audit integrity if client personnel changes. Support legacy unstructured contacts via fallback scalar fields.

---

## 4. Target Data Model & API Contract

```prisma
model Lead {
  id                    String         @id @default(cuid())
  leadNumber            String         @unique
  clientId              String?
  client                Client?        @relation(fields: [clientId], references: [id])
  clientContactId       String?
  clientContact         ClientContact? @relation(fields: [clientContactId], references: [id])
  contactNameSnapshot   String?
  contactEmailSnapshot  String?
  contactPhoneSnapshot  String?
  // Fallback legacy scalars
  contactPerson         String?
  contactEmail          String?
  contactPhone          String?
}
```

---

## 5. Test Scenarios & Acceptance Criteria

| Test Case ID | Test Scenario | Expected Result | Pass / Fail |
| :---: | :--- | :--- | :---: |
| **TC-DEMO-03-01** | Filter contacts by client | Dropdown displays only contacts belonging to selected `clientId` | [ ] |
| **TC-DEMO-03-02** | Contact snapshot persistence | Selected contact details copied to `contact*Snapshot` columns | [ ] |
| **TC-DEMO-03-03** | Master contact update | Modifying `ClientContact` does not alter snapshot on existing leads | [ ] |

---

## 6. Sign-off and Approvals

| Stakeholder Role | Name & Title | Signature | Date |
| :--- | :--- | :--- | :--- |
| **Commercial Process Owner** | | ____________________ | YYYY-MM-DD |
| **Lead Technical Architect** | | ____________________ | YYYY-MM-DD |

---

## 7. Document Revision History

| Version | Date | Author / Role | Summary of Changes |
| :---: | :---: | :--- | :--- |
| `v0.01` | 2026-08-28 | Antigravity AI | Initial functional specification creation. |
| `v0.02` | 2026-08-28 | Antigravity AI | Added Section 2: Immediate Operational Effect Post-Implementation. |
| `v0.03` | 2026-09-02 | Antigravity AI | **Baseline v1.00 Synchronization**: Incorporated Decision 3.1 (dynamic client contact filtering, point-in-time contact snapshots, and legacy scalar fallback support). |
