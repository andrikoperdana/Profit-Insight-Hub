# Activate - SPH | WRICEF Functional Specification Document (FSD)

**Document Information**
- **Project Name**: SecureProfit Hub (SPH) Implementation
- **Parent Master FSD**: `10-03_Explore-05_WRICEF_Functional_Specification_FSD_SPH_v0.03.md`
- **Document Identifier**: SPH-FSD-E-DEMO-08
- **WRICEF Title**: Stage-Based Default Probability % Automation
- **WRICEF Type**: Enhancement (E)
- **Phase**: 03 - Explore / 04 - Realize
- **Workstream**: Commercial Pipeline & Forecasting
- **Sprint Allocation**: Sprint 2 (2 Story Points)
- **Complexity**: Simple
- **Functional Author**: Antigravity AI (Commercial Track)
- **Business Process Owner**: Commercial Lead
- **Version**: v0.03
- **Status**: Draft (Decision Baseline Synchronized)
- **Date**: 2026-09-02
- **Decision Grounding**: Decision 8.1 (`Answer to - SecureProfit-Hub-Master-Recommendation-All-12-FSD-ID-2026-08.md v1.00`)

---

## 1. Business Requirement & Objective
- **Business Need**: Pipeline forecasting requires standardized win probability percentages per sales stage, while capturing audited reasons when sales reps manually override the system defaults.
- **User Story**: *As a Commercial Director, I want win probabilities automated across the 6 canonical sales stages, with mandatory reason logging for manual overrides.*

---

## 2. Immediate Operational & System Effect Post-Implementation

> [!IMPORTANT]
> **Developer Goal & Operational Target**:
> Standardizes commercial weighted pipeline calculations and enforces audit compliance on manual forecasting adjustments.

### Immediate Effects:
1. **Canonical Stage Mapping**: Locks 6 standardized stages (`DISCOVERY` 10%, `QUALIFIED` 30%, `PROPOSAL` 60%, `NEGOTIATION` 80%, `WON` 100%, `LOST` 0%).
2. **Automated Stage Sync**: Transitions auto-update deal probability without manual rep entry.
3. **Audited Reason Logging**: Requires `probabilityOverrideReason` whenever a rep alters default probability.

---

## 3. Approved Baseline Decisions & Implementation Invariants

* **Decision 8.1 `[APPROVED]`**: Lock the 6 canonical sales stages (`DISCOVERY` 10%, `QUALIFIED` 30%, `PROPOSAL` 60%, `NEGOTIATION` 80%, `WON` 100%, `LOST` 0%). Auto-populate win probabilities upon stage transition. Allow authorized sales reps to manually override win probability % only when providing a mandatory, audited `probabilityOverrideReason`.

---

## 4. Test Scenarios & Acceptance Criteria

| Test Case ID | Test Scenario | Expected Result | Pass / Fail |
| :---: | :--- | :--- | :---: |
| **TC-DEMO-08-01** | Advance lead to `PROPOSAL` | Probability automatically set to 60% | [ ] |
| **TC-DEMO-08-02** | Manual override with reason | Override saved; `probabilityOverrideReason` persisted | [ ] |
| **TC-DEMO-08-03** | Manual override without reason | Validation error blocks update: reason is mandatory | [ ] |

---

## 5. Sign-off and Approvals

| Stakeholder Role | Name & Title | Signature | Date |
| :--- | :--- | :--- | :--- |
| **Commercial Process Owner** | | ____________________ | YYYY-MM-DD |
| **Lead Technical Architect** | | ____________________ | YYYY-MM-DD |

---

## 6. Document Revision History

| Version | Date | Author / Role | Summary of Changes |
| :---: | :---: | :--- | :--- |
| `v0.01` | 2026-08-28 | Antigravity AI | Initial functional specification creation. |
| `v0.02` | 2026-08-28 | Antigravity AI | Added Section 2: Immediate Operational Effect Post-Implementation. |
| `v0.03` | 2026-09-02 | Antigravity AI | **Baseline v1.00 Synchronization**: Incorporated Decision 8.1 (6 canonical stages, automatic probability population, and mandatory audited `probabilityOverrideReason`). |
