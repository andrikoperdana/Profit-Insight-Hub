# Activate - SPH | WRICEF Functional Specification Document (FSD)

**Document Information**
- **Project Name**: SecureProfit Hub (SPH) Implementation
- **Parent Master FSD**: `10-03_Explore-05_WRICEF_Functional_Specification_FSD_SPH_v0.03.md`
- **Document Identifier**: SPH-FSD-W-DEMO-10
- **WRICEF Title**: Proposal Stage Budgeting & Finance Margin Gate
- **WRICEF Type**: Workflow (W)
- **Phase**: 03 - Explore / 04 - Realize
- **Workstream**: Commercial Gating & Margin Governance
- **Sprint Allocation**: Sprint 2 (5 Story Points)
- **Complexity**: Complex
- **Functional Author**: Antigravity AI (Finance & Commercial Track)
- **Business Process Owner**: Finance Lead & Commercial Lead
- **Version**: v0.03
- **Status**: Draft (Decision Baseline Synchronized)
- **Date**: 2026-09-02
- **Decision Grounding**: Decision 10.1a, 10.1b (`Answer to - SecureProfit-Hub-Master-Recommendation-All-12-FSD-ID-2026-08.md v1.00`)

---

## 1. Business Requirement & Objective
- **Business Need**: To prevent unprofitable contract commitments, commercial proposals must include itemized cost breakdowns, calculate gross margins against configurable VAT snapshots, and require independent Finance approval with strict Separation of Duties (SoD).
- **User Story**: *As a Finance Lead, I want commercial proposals reviewed and approved through an SoD gate, with mandatory dual Management escalation for deals with margins < 20%.*

---

## 2. Immediate Operational & System Effect Post-Implementation

> [!IMPORTANT]
> **Developer Goal & Operational Target**:
> Eliminates unbudgeted deal margin erosion by enforcing rigorous commercial budget revisions, VAT rate snapshots, and independent Finance approval gates.

### Immediate Effects:
1. **Versioned Budget Revisions**: Tracks proposed costs in `CommercialBudgetRevision`.
2. **Configurable VAT Snapshot**: Snapshots active tax rate (`Decimal(5, 2)`) at proposal submission.
3. **Separation of Duties (SoD)**: Blocks commercial deal owners from self-approving margin gates.
4. **Dual Management Escalation**: Mandates co-approval from `MANAGEMENT` whenever proposed margin is $< 20\%$.

---

## 3. Approved Baseline Decisions & Implementation Invariants

* **Decision 10.1a `[APPROVED]`**: Calculate commercial margin using the gross margin formula: $\text{Gross Margin \%} = \frac{\text{Contract Value (excl. VAT)} - \text{Baseline Cost}}{\text{Contract Value (excl. VAT)}} \times 100\%$. Maintain versioned budget proposals in `CommercialBudgetRevision`. Snapshot configurable VAT rates (`Decimal(5, 2)`) at submission.
* **Decision 10.1b `[APPROVED]`**: Enforce Separation of Duties (SoD): the commercial lead/owner cannot approve their own margin proposal. Require mandatory sign-off from `FINANCE_LEAD`. If the proposed margin is $< 20\%$, trigger mandatory dual escalation requiring co-approval from `MANAGEMENT`.

---

## 4. Target Data Model & Gating State Machine

```prisma
model CommercialBudgetRevision {
  id                String    @id @default(cuid())
  leadId            String
  lead              Lead      @relation(fields: [leadId], references: [id], onDelete: Cascade)
  revisionNumber    Int       @default(1)
  estimatedValue    Decimal   @db.Decimal(15, 2)
  estimatedCost     Decimal   @db.Decimal(15, 2)
  grossMarginPct    Decimal   @db.Decimal(5, 2)
  vatRateSnapshot   Decimal   @db.Decimal(5, 2)
  status            String    @default("PENDING_APPROVAL") // PENDING_APPROVAL, APPROVED, REJECTED, ESCALATED
  submittedById     String
  approvedById      String?
  managementCoApprId String?
  createdAt         DateTime  @default(now())
}
```

---

## 5. Test Scenarios & Acceptance Criteria

| Test Case ID | Test Scenario | Expected Result | Pass / Fail |
| :---: | :--- | :--- | :---: |
| **TC-DEMO-10-01** | Submit margin $\ge 25\%$ | Routes to Finance Lead; approved cleanly upon sign-off | [ ] |
| **TC-DEMO-10-02** | Owner attempts self-approval | Blocked with `HTTP 403 Forbidden` (SoD Violation) | [ ] |
| **TC-DEMO-10-03** | Submit margin $< 20\%$ | Status set to `ESCALATED`; requires Finance + Management dual approvals | [ ] |

---

## 6. Sign-off and Approvals

| Stakeholder Role | Name & Title | Signature | Date |
| :--- | :--- | :--- | :--- |
| **Finance Process Owner** | | ____________________ | YYYY-MM-DD |
| **Commercial Process Owner** | | ____________________ | YYYY-MM-DD |
| **Lead Technical Architect** | | ____________________ | YYYY-MM-DD |

---

## 7. Document Revision History

| Version | Date | Author / Role | Summary of Changes |
| :---: | :---: | :--- | :--- |
| `v0.01` | 2026-08-28 | Antigravity AI | Initial functional specification creation. |
| `v0.02` | 2026-08-28 | Antigravity AI | Added Section 2: Immediate Operational Effect Post-Implementation. |
| `v0.03` | 2026-09-02 | Antigravity AI | **Baseline v1.00 Synchronization**: Incorporated Decisions 10.1a & 10.1b (`CommercialBudgetRevision` model, configurable `Decimal(5, 2)` VAT snapshots, SoD enforcement, and $<20\%$ dual Management escalation). |
