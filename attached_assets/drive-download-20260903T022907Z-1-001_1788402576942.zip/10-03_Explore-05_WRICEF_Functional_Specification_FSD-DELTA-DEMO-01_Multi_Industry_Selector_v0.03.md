# Activate - SPH | WRICEF Functional Specification Document (FSD)

**Document Information**
- **Project Name**: SecureProfit Hub (SPH) Implementation
- **Parent Master FSD**: `10-03_Explore-05_WRICEF_Functional_Specification_FSD_SPH_v0.03.md`
- **Document Identifier**: SPH-FSD-E-DEMO-01
- **WRICEF Title**: Multi-Choice Industry Sector Selector at Lead Creation
- **WRICEF Type**: Enhancement (E)
- **Phase**: 03 - Explore / 04 - Realize
- **Workstream**: Commercial Intake & CRM
- **Sprint Allocation**: Sprint 1 (2 Story Points)
- **Complexity**: Simple
- **Functional Author**: Antigravity AI (Commercial Track)
- **Business Process Owner**: Commercial Lead
- **Version**: v0.03
- **Status**: Draft (Decision Baseline Synchronized)
- **Date**: 2026-09-02
- **Decision Grounding**: Decision 1.1, 1.2, 1.3 (`Answer to - SecureProfit-Hub-Master-Recommendation-All-12-FSD-ID-2026-08.md v1.00`)

---

## 1. Business Requirement & Objective
- **Business Need**: Large corporate clients and conglomerates often span multiple industries (e.g., Financial Services and Telecommunications, or Healthcare and Government). Restricting lead creation to a single industry dropdown prevents multi-sector account segmentation, analytics, and targeted consultant staffing.
- **User Story**: *As a Sales AE, I want to select multiple industry sectors during lead creation, so that multi-sector corporate accounts are categorized accurately in the pipeline.*
- **Trigger Event**: User opens the "Create Lead" modal in `web/src/pages/Leads.tsx` and interacts with the Industry field.

---

## 2. Immediate Operational & System Effect Post-Implementation

> [!IMPORTANT]
> **Developer Goal & Operational Target**:
> This customization transforms how SPH classifies enterprise market segments, shifting from rigid single-string values to searchable multi-dimensional industry arrays and normalized sector join entities.

### Immediate Effects:
1. **Multi-Sector Account Categorization**: Sales AEs can immediately tag conglomerate and multi-sector opportunities with composite industry sectors (e.g., Banking + Telecommunications) without data truncation.
2. **Dynamic Pipeline & Kanban Filtering**: The Leads pipeline filtering engine can instantly query and aggregate deals across overlapping industry sectors.
3. **Targeted Consultant Skill Pre-Matching**: Eliminates miscategorized accounts, enabling the Resource Matching Recommender (`E-03`) to pre-screen consultants with the exact industry compliance domain experience (e.g., PCI-DSS for Banking, HIPAA for Healthcare).

---

## 3. Approved Baseline Decisions & Implementation Invariants

* **Decision 1.1 `[APPROVED]`**: Centralize catalog administration exclusively under `SITE_ADMIN` and `MANAGEMENT` roles. Implement a flat operational list of sectors for initial go-live while incorporating a self-referencing `parentSectorId` column in the database model.
* **Decision 1.2 `[APPROVED]`**: Discard percentage weights in favor of a normalized `LeadSector` join table with a boolean `isPrimary` flag. Enforce the exactly-one primary sector rule at the database level using a PostgreSQL partial unique index (`one_primary_sector_per_lead`).
* **Decision 1.3 `[APPROVED]`**: Implement soft-deletion (`isActive Boolean`) for sectors. Preserve historical links on existing leads. On lead updates (`PUT /api/leads/:id`), compute diff set (`requestedIds \ existingIds`); reject if new inactive sectors are added. Capture free-text for "Other" sectors in `LeadSector.otherDetail`.

---

## 4. Functional Architecture & Data Flow

```mermaid
flowchart TD
    User["Sales AE / Commercial Ops"] -->|1. Opens Lead Creation Modal| UI["Lead Intake Form (React UI)"]
    UI -->|2. Selects Multiple Sectors + Designates Primary| Chip["Multi-Select Tag / Chip Component"]
    Chip -->|3. Submits Form (POST /api/leads)| API["Leads Controller (routes/leads.ts)"]
    API -->|4. Validates Diff & Exactly-One Primary| DB["PostgreSQL Database (Prisma)"]
    DB -->|5. Persists Lead & LeadSector Join Table| LeadRecord["Lead Record & LeadSector Join Records"]
```

---

## 5. Detailed Functional Requirements & Business Rules

### 5.1 UI & Frontend Behavior
1. **Component Type**: Searchable multi-select chip input with radio/toggle for designating the **Primary Sector**.
2. **Catalog Administration**: Maintained via `IndustrySector` master model; only active sectors (`isActive = true`) appear in creation dropdowns.
3. **Selection Rule**: Minimum 1 industry required; exactly 1 primary sector must be marked.
4. **"Other" Sector Free-Text**: If "Other" is selected, dynamically render a text input capturing `otherDetail`.

### 5.2 Target Data Model & API Contract
- **Prisma Schema (Target Extension)**:
  ```prisma
  model IndustrySector {
    id             String           @id @default(cuid())
    code           String           @unique
    name           String
    parentSectorId String?
    parentSector   IndustrySector?  @relation("SectorHierarchy", fields: [parentSectorId], references: [id])
    subSectors     IndustrySector[] @relation("SectorHierarchy")
    isActive       Boolean          @default(true)
    leads          LeadSector[]
    createdAt      DateTime         @default(now())
    updatedAt      DateTime         @updatedAt
  }

  model LeadSector {
    id          String         @id @default(cuid())
    leadId      String
    lead        Lead           @relation(fields: [leadId], references: [id], onDelete: Cascade)
    sectorId    String
    sector      IndustrySector @relation(fields: [sectorId], references: [id])
    isPrimary   Boolean        @default(false)
    otherDetail String?

    @@unique([leadId, sectorId])
  }
  ```
- **PostgreSQL Partial Unique Index**:
  ```sql
  CREATE UNIQUE INDEX one_primary_sector_per_lead 
  ON "LeadSector" ("leadId") 
  WHERE "isPrimary" = true;
  ```

---

## 6. Test Scenarios & Acceptance Criteria

| Test Case ID | Test Scenario | Input Data | Expected Result | Pass / Fail |
| :---: | :--- | :--- | :--- | :---: |
| **TC-DEMO-01-01** | Standard multi-sector selection | Select Banking + Telecom (Banking as Primary) | Form validates; `LeadSector` join records created with 1 Primary | [ ] |
| **TC-DEMO-01-02** | Validation on 0 primary sectors | Select 2 sectors without marking primary | Form blocks submit; displays required primary sector error | [ ] |
| **TC-DEMO-01-03** | Inactive sector diff validation | Add newly inactive sector on update | API returns `HTTP 400 Bad Request` | [ ] |
| **TC-DEMO-01-04** | "Other" sector free-text capture | Select "Other" + enter "Aerospace R&D" | `otherDetail` successfully persisted in `LeadSector` | [ ] |

---

## 7. Sign-off and Approvals

| Stakeholder Role | Name & Title | Signature | Date |
| :--- | :--- | :--- | :--- |
| **Commercial Process Owner** | | ____________________ | YYYY-MM-DD |
| **Lead Technical Architect** | | ____________________ | YYYY-MM-DD |

---

## 8. Document Revision History

| Version | Date | Author / Role | Summary of Changes |
| :---: | :---: | :--- | :--- |
| `v0.01` | 2026-08-28 | Antigravity AI | Initial functional specification creation. |
| `v0.02` | 2026-08-28 | Antigravity AI | Added dedicated Section 2: Immediate Operational & System Effect Post-Implementation. |
| `v0.03` | 2026-09-02 | Antigravity AI | **Baseline v1.00 Synchronization**: Incorporated Decisions 1.1, 1.2, 1.3 (normalized `LeadSector` join model, PostgreSQL partial unique index `one_primary_sector_per_lead`, diff validation on `PUT`, and `otherDetail` free-text capture). |
