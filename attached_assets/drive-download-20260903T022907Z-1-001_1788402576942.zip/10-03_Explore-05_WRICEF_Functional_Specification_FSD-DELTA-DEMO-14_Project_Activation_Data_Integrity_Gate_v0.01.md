# Activate - SPH | WRICEF Functional Specification Document (FSD)

**Document Information**
- **Project Name**: SecureProfit Hub (SPH) Implementation
- **Parent Master FSD**: `10-03_Explore-05_WRICEF_Functional_Specification_FSD_SPH_v0.05.md`
- **Document Identifier**: SPH-FSD-E-DEMO-14
- **WRICEF Title**: Project Activation Data Integrity Hard-Gate & Contract Line Classification Engine
- **WRICEF Type**: Enhancement (E) / Workflow (W)
- **Phase**: 03 - Explore / 04 - Realize
- **Workstream**: Stream 1 — Commercial Intake & Project Genesis / Stream 2 — Resource Allocation
- **Sprint Allocation**: Sprint 3 (5 Story Points)
- **Complexity**: Medium / Complex
- **Functional Author**: Antigravity AI (PMO & Governance Track)
- **Business Process Owner**: PMO Lead & Finance Lead
- **Version**: v0.01
- **Status**: Draft
- **Date**: 2026-09-02
- **Audit Grounding**: Internal Audit Finding (223 Historical Projects with Missing Mandays/Dates & Negative Expense Cost Masking)
- **Stakeholder Grounding**: Handover from Concept Clarification Meeting (1 Sep 2026)

---

## 1. Business Requirement & Objective

- **Business Need**: An internal portfolio audit uncovered 223 historical projects created without planned mandays/budget hours (especially Time & Material projects), missing chronological project end dates, and exhibiting recurring contract line classification errors where sales reps recorded third-party software as negative expenses to artificially mask costs. A non-bypassable pre-activation gate and standardized contract line classification engine must be enforced.
- **User Story**: *As a PMO Controller & Finance Lead, I want a non-bypassable pre-activation data integrity gate and structured contract line classification, so that projects cannot transition to ACTIVE without verified non-zero mandays, valid dates, and positive contract line items.*
- **Trigger Event**: Project Manager or Commercial Lead attempts to transition a project from `DRAFT` / `OBSERVATION` to `ACTIVE` via `PATCH /api/projects/:id`.

---

## 2. Immediate Operational & System Effect Post-Implementation

> [!IMPORTANT]
> **Developer Goal & Operational Target**:
> Eradicates unbudgeted project creation and cost masking by enforcing a backend hard-lock on project activation, providing a real-time readiness pre-check API, and standardizing contract line item classifications.

### Immediate Effects:
1. **Mandatory Mandays Hard-Lock**: For all commercial projects (`kind = "CLIENT"`), `plannedMandays` must be strictly positive ($\text{plannedMandays} > 0.00$).
2. **T&M Rate Enforcement**: Assigned resources on Time & Materials projects must have active non-zero daily rates in `ProjectResourceRate`.
3. **Mandatory Chronological Dates**: Project `startDate` and `endDate` are required; system strictly rejects `endDate < startDate`.
4. **Contract Line Classification Standards**: Eliminates negative expense masking by standardizing lines into `PRODUCT_SOLUTION` vs `PROFESSIONAL_SERVICE` with positive selling/cost prices.
5. **Pre-Activation Health Check Endpoint**: `GET /api/projects/:id/activation-readiness` returns a live status checklist with exact failure codes and redirect tabs.
6. **Atomic Hard-Gate**: `PATCH /api/projects/:id` (to `status: ACTIVE`) rejects invalid projects with `HTTP 422 Unprocessable Entity` (`ACTIVATION_GATE_VIOLATION`).

---

## 3. Approved Baseline Decisions & Implementation Invariants

```mermaid
flowchart TD
    subgraph READINESS_CHECK["1. Pre-Activation Health Check API"]
        PM["Project Manager / Lead"] -->|1. Opens Project Activation Tab| UI["Project Settings UI"]
        UI -->|2. GET /api/projects/:id/activation-readiness| CheckAPI["Readiness Evaluator (lib/projectValidators.ts)"]
        CheckAPI -->|3. Evaluates 8 Invariants| Checklist["Checklist Result (Pass/Fail per Invariant)"]
    end

    subgraph ATOMIC_GATE["2. Activation Transition Hard-Gate"]
        PM -->|4. Clicks 'Activate Project'| Submit["PATCH /api/projects/:id (status: ACTIVE)"]
        Submit --> CheckAPI
        CheckAPI -- All Passed --> Activate["1. Project Status -> ACTIVE\n2. Lock Client Name (DELTA-DEMO-12)\n3. Initialize Baseline v1.00 (DELTA-DEMO-11)"]
        CheckAPI -- Any Violation --> Block["HTTP 422 Unprocessable Entity (ACTIVATION_GATE_VIOLATION)"]
    end
```

### The 8 Core Activation Invariants:
1. **`INV-ACT-01` (Non-Zero Mandays)**: For `kind = "CLIENT"`, `plannedMandays > 0.00` across workstreams.
2. **`INV-ACT-02` (Chronological Dates)**: `startDate` and `endDate` are non-null and `endDate >= startDate`.
3. **`INV-ACT-03` (Contract Lines Classification)**: At least one `ProjectContractLine` exists; all `sellingPrice > 0.00` (zero negative lines permitted).
4. **`INV-ACT-04` (T&M Rate Card Completeness)**: If `pricingModel == TIME_AND_MATERIALS`, every assigned consultant has a non-zero rate in `ProjectResourceRate`.
5. **`INV-ACT-05` (PM Assigned)**: `projectManagerId` is non-null and references an active `PROJECT_MANAGER` user.
6. **`INV-ACT-06` (Primary BU Assigned)**: `businessUnitId` is non-null (`DELTA-DEMO-04`).
7. **`INV-ACT-07` (Commercial Margin Gate Cleared)**: Proposal margin approved by Finance (`DELTA-DEMO-10`).
8. **`INV-ACT-08` (Client Entity Bound)**: Valid `clientId` bound and verified (`DELTA-DEMO-03`, `DELTA-DEMO-12`).

---

## 4. Target Data Model Specification (`schema.prisma`)

```prisma
enum PricingModel {
  FIXED_FEE
  TIME_AND_MATERIALS
  RETAINER
}

enum LineItemType {
  PROFESSIONAL_SERVICE
  PRODUCT_SOLUTION
  MAINTENANCE_SUBSCRIPTION
}

model ProjectContractLine {
  id              String             @id @default(cuid())
  projectId       String
  project         Project            @relation(fields: [projectId], references: [id], onDelete: Cascade)
  lineType        LineItemType       @default(PROFESSIONAL_SERVICE)
  description     String
  sellingPrice    Decimal            @db.Decimal(15, 2)  // Must be > 0 (No negative amounts)
  costPrice       Decimal            @db.Decimal(15, 2)  // Direct vendor / pass-through cost
  marginPct       Decimal            @db.Decimal(5, 2)   // Computed: ((selling - cost) / selling) * 100
  plannedMandays  Decimal?           @db.Decimal(6, 2)   // Required if lineType == PROFESSIONAL_SERVICE
  workstreamId    String?
  workstream      ProjectWorkstream? @relation(fields: [workstreamId], references: [id], onDelete: SetNull)
  createdAt       DateTime           @default(now())
  updatedAt       DateTime           @updatedAt

  @@index([projectId, lineType])
}
```

---

## 5. API Endpoint Specifications

### 5.1 Pre-Activation Readiness Check
- **Endpoint**: `GET /api/projects/:id/activation-readiness`
- **RBAC Guard**: Authenticated project viewer (`PROJECT_MANAGER`, `MANAGEMENT`, `FINANCE_LEAD`)
- **Response Schema (`HTTP 200 OK`)**:
  ```json
  {
    "projectId": "prj_ckx91827",
    "canActivate": false,
    "blockerCount": 2,
    "checklist": [
      {
        "code": "MANDAYS_REQUIRED",
        "label": "Planned Mandays / Budget Hours",
        "passed": false,
        "detail": "Project has 0.00 planned mandays. Must allocate budget hours before activation.",
        "targetTab": "wbs-workstreams"
      },
      {
        "code": "CHRONOLOGICAL_DATES",
        "label": "Project Start and End Dates",
        "passed": true,
        "detail": "Start: 2026-10-01, End: 2026-12-31 (Valid)",
        "targetTab": "overview"
      },
      {
        "code": "CONTRACT_LINES_VALID",
        "label": "Contract Line Items & Pricing",
        "passed": false,
        "detail": "Negative line item detected. Solutions must be entered as positive PRODUCT_SOLUTION lines.",
        "targetTab": "commercial-lines"
      }
    ]
  }
  ```

### 5.2 Atomic Project Activation Gate
- **Endpoint**: `PATCH /api/projects/:id`
- **Request Body**: `{"status": "ACTIVE"}`
- **Validation Processing**:
  - Executes `evaluateActivationReadiness(project)`.
  - If any invariant fails, aborts transaction immediately and returns `HTTP 422 Unprocessable Entity` with error details payload.

---

## 6. Test Scenarios & Acceptance Criteria

| Test Case ID | Test Scenario | Input Data | Expected Result | Pass / Fail |
| :---: | :--- | :--- | :--- | :---: |
| **TC-DEMO-14-01** | Activate project with 0 mandays | `plannedMandays = 0` | Blocked with `HTTP 422` (`MANDAYS_REQUIRED`) | [ ] |
| **TC-DEMO-14-02** | Activate with `endDate < startDate` | `startDate: 2026-11-01`, `endDate: 2026-10-01` | Blocked with `HTTP 422` (`INVALID_DATE_RANGE`) | [ ] |
| **TC-DEMO-14-03** | Enter negative contract line | `sellingPrice = -50000000` | Schema validation rejects negative price; `HTTP 400` | [ ] |
| **TC-DEMO-14-04** | T&M project with unrated resource | Assigned consultant without rate card | Blocked with `HTTP 422` (`TM_RATE_MISSING`) | [ ] |
| **TC-DEMO-14-05** | Activate fully compliant project | All 8 invariants satisfied | Status transitions to `ACTIVE`; baseline initialized | [ ] |

---

## 7. Sign-off and Approvals

| Stakeholder Role | Name & Title | Signature | Date | Status |
| :--- | :--- | :--- | :---: | :---: |
| **PMO Process Owner** | | ____________________ | YYYY-MM-DD | Draft |
| **Finance Process Owner** | | ____________________ | YYYY-MM-DD | Draft |
| **Lead Technical Architect** | | ____________________ | YYYY-MM-DD | Draft |

---

## 8. Document Revision History

| Version | Date | Author / Role | Summary of Changes |
| :---: | :---: | :--- | :--- |
| `v0.01` | 2026-09-02 | Antigravity AI (PMO Track) | Initial functional specification creation for DELTA-DEMO-14 (Project Activation Data Integrity Hard-Gate & Contract Line Classification Engine). |
