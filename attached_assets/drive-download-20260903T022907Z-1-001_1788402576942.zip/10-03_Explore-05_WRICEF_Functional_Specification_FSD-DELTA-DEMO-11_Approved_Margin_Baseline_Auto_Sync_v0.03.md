# Activate - SPH | WRICEF Functional Specification Document (FSD)

**Document Information**
- **Project Name**: SecureProfit Hub (SPH) Implementation
- **Parent Master FSD**: `10-03_Explore-05_WRICEF_Functional_Specification_FSD_SPH_v0.03.md`
- **Document Identifier**: SPH-FSD-E-DEMO-11
- **WRICEF Title**: Approved Margin Project Baseline Auto-Sync Engine
- **WRICEF Type**: Enhancement (E) / Workflow (W)
- **Phase**: 03 - Explore / 04 - Realize
- **Workstream**: Delivery Financial Control & Baseline Governance
- **Sprint Allocation**: Sprint 2 (5 Story Points)
- **Complexity**: Medium
- **Functional Author**: Antigravity AI (Finance Track)
- **Business Process Owner**: Finance Lead & Delivery Lead
- **Version**: v0.03
- **Status**: Draft (Decision Baseline Synchronized)
- **Date**: 2026-09-02
- **Decision Grounding**: Decision 11.1 (`Answer to - SecureProfit-Hub-Master-Recommendation-All-12-FSD-ID-2026-08.md v1.00`)

---

## 1. Business Requirement & Objective
- **Business Need**: Once a lead proposal is approved by Finance and converted to Won, the approved commercial budget must automatically initialize the delivery project baseline (`ProjectBaseline`) with exact decimal precision, protected against race conditions.
- **User Story**: *As a Project Manager & Finance Lead, I want the approved commercial budget automatically synced to the delivery project baseline, establishing the official v1.00 EVM baseline.*

---

## 2. Immediate Operational & System Effect Post-Implementation

> [!IMPORTANT]
> **Developer Goal & Operational Target**:
> Connects presales budgeting directly to delivery EVM accounting, establishing an immutable `v1.00` project baseline upon commercial conversion.

### Immediate Effects:
1. **Lifecycle Machine Separation**: Distinguishes `ACTIVATION` (automatic initialization) from `CHANGE_REQUEST` (governed mid-project amendments `v1.01+`).
2. **PostgreSQL Partial Unique Index**: Protects exactly-one current baseline rule (`one_current_baseline_per_project`).
3. **High-Precision Decimal Serialization**: Migrates monetary values to `Decimal(15, 2)` preventing floating-point rounding errors.

---

## 3. Approved Baseline Decisions & Implementation Invariants

* **Decision 11.1 `[APPROVED]`**: Establish distinct baseline synchronization lifecycles: `ACTIVATION` (automatic initialization upon Won conversion) vs `CHANGE_REQUEST` (versioned amendments `v1.01+` during delivery). Implement the target `ProjectBaseline` model with `Decimal(15, 2)` monetary precision, protected by PostgreSQL partial unique index `one_current_baseline_per_project` (`WHERE "isCurrent" = true`). Enforce discriminated union validations and idempotent retry ordering.

---

## 4. Target Data Model & Database Invariants

```prisma
enum BaselineTriggerType {
  ACTIVATION
  CHANGE_REQUEST
}

model ProjectBaseline {
  id            String              @id @default(cuid())
  projectId     String
  project       Project             @relation(fields: [projectId], references: [id], onDelete: Cascade)
  versionNumber String              // e.g. "v1.00", "v1.01"
  contractValue Decimal             @db.Decimal(15, 2)
  baselineCost  Decimal             @db.Decimal(15, 2)
  targetMargin  Decimal             @db.Decimal(5, 2)
  triggerType   BaselineTriggerType
  isCurrent     Boolean             @default(true)
  approvedAt    DateTime            @default(now())
  approvedById  String
}
```

```sql
-- PostgreSQL Partial Unique Index
CREATE UNIQUE INDEX one_current_baseline_per_project 
ON "ProjectBaseline" ("projectId") 
WHERE "isCurrent" = true;
```

---

## 5. Test Scenarios & Acceptance Criteria

| Test Case ID | Test Scenario | Expected Result | Pass / Fail |
| :---: | :--- | :--- | :---: |
| **TC-DEMO-11-01** | Convert Won lead to project | Auto-creates `ProjectBaseline` with `versionNumber = "v1.00"`, `isCurrent = true` | [ ] |
| **TC-DEMO-11-02** | Approve Change Request | Sets prior baseline `isCurrent = false`, creates `v1.01` with `isCurrent = true` | [ ] |
| **TC-DEMO-11-03** | Partial index constraint check | Direct database attempt to set 2 baselines `isCurrent = true` fails with unique error | [ ] |

---

## 6. Sign-off and Approvals

| Stakeholder Role | Name & Title | Signature | Date |
| :--- | :--- | :--- | :--- |
| **Finance Process Owner** | | ____________________ | YYYY-MM-DD |
| **Delivery Process Owner** | | ____________________ | YYYY-MM-DD |
| **Commercial Process Owner** | | ____________________ | YYYY-MM-DD |

---

## 7. Document Revision History

| Version | Date | Author / Role | Summary of Changes |
| :---: | :---: | :--- | :--- |
| `v0.01` | 2026-08-28 | Antigravity AI | Initial functional specification creation. |
| `v0.02` | 2026-08-28 | Antigravity AI | Added Section 2: Immediate Operational Effect Post-Implementation. |
| `v0.03` | 2026-09-02 | Antigravity AI | **Baseline v1.00 Synchronization**: Incorporated Decision 11.1 (`ACTIVATION` vs `CHANGE_REQUEST` lifecycle, `ProjectBaseline` target model with `Decimal(15, 2)`, partial unique index `one_current_baseline_per_project`, and discriminated union validation). |
