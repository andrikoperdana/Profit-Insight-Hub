# Activate - SPH | WRICEF Functional Specification Document (FSD)

**Document Information**
- **Project Name**: SecureProfit Hub (SPH) Implementation
- **Parent Master FSD**: `10-03_Explore-05_WRICEF_Functional_Specification_FSD_SPH_v0.03.md`
- **Document Identifier**: SPH-FSD-F-DEMO-06
- **WRICEF Title**: Read-Only Sequential Lead ID Preview Form Badge
- **WRICEF Type**: Form (F) / Enhancement (E)
- **Phase**: 03 - Explore / 04 - Realize
- **Workstream**: Commercial Intake & UI
- **Sprint Allocation**: Sprint 1 (2 Story Points)
- **Complexity**: Simple
- **Functional Author**: Antigravity AI (Commercial Track)
- **Business Process Owner**: Commercial Lead
- **Version**: v0.03
- **Status**: Draft (Decision Baseline Synchronized)
- **Date**: 2026-09-02
- **Decision Grounding**: Decision 6.1 (`Answer to - SecureProfit-Hub-Master-Recommendation-All-12-FSD-ID-2026-08.md v1.00`)

---

## 1. Business Requirement & Objective
- **Business Need**: Sales reps need immediate visibility of the sequential identifier assigned to their opportunity (`LEAD/YYYY/NNN`) with strict thread safety and no duplicate collision under high concurrency.
- **User Story**: *As a Sales AE, I want a read-only badge showing the prospective Lead ID during creation, with guaranteed sequential generation on submit.*

---

## 2. Immediate Operational & System Effect Post-Implementation

> [!IMPORTANT]
> **Developer Goal & Operational Target**:
> Delivers atomic, high-concurrency lead sequence generation inside the same database transaction as `Lead.create`, eliminating race conditions and duplicate ID errors.

### Immediate Effects:
1. **Thread-Safe Allocation**: `allocateNextLeadNumber(tx)` executes inside `tx.lead.create` with `SELECT ... FOR UPDATE` locking.
2. **WIB Timezone Alignment**: Resets sequence counter annually at midnight Western Indonesia Time (UTC+7).
3. **Uniqueness-First Reconciliation**: Guarantees zero sequence collision even under concurrent creation bursts.

---

## 3. Approved Baseline Decisions & Implementation Invariants

* **Decision 6.1 `[APPROVED]`**: Allocate formatted sequential lead IDs (`LEAD/YYYY/NNN`) atomically inside the same database transaction as `tx.lead.create` using `allocateNextLeadNumber(tx)` with `SELECT ... FOR UPDATE` row locking. Reset sequence annually at midnight Western Indonesia Time (WIB, UTC+7). Implement uniqueness-first gap reconciliation.

---

## 4. Technical Implementation & Sequence Logic

```typescript
// Atomic Same-Tx Sequence Allocation Example
export async function allocateNextLeadNumber(tx: Prisma.TransactionClient, year: number): Promise<string> {
  const counter = await tx.sequenceCounter.upsert({
    where: { name: `LEAD_${year}` },
    create: { name: `LEAD_${year}`, nextValue: 2 },
    update: { nextValue: { increment: 1 } },
  });
  const seq = String(counter.nextValue - 1).padStart(3, "0");
  return `LEAD/${year}/${seq}`;
}
```

---

## 5. Test Scenarios & Acceptance Criteria

| Test Case ID | Test Scenario | Expected Result | Pass / Fail |
| :---: | :--- | :--- | :---: |
| **TC-DEMO-06-01** | Lead creation ID generation | Formats sequential ID as `LEAD/2026/001`, `002`, etc. | [ ] |
| **TC-DEMO-06-02** | High-concurrency creation | Concurrent submits generate distinct sequential numbers with 0 duplicates | [ ] |
| **TC-DEMO-06-03** | Annual rollover at WIB | Resets to `/001` at 00:00:00 WIB on Jan 1 | [ ] |

---

## 6. Sign-off and Approvals

| Stakeholder Role | Name & Title | Signature | Date |
| :--- | :--- | :--- | :--- |
| **Commercial Process Owner** | | ____________________ | YYYY-MM-DD |
| **Lead Technical Architect** | | ____________________ | YYYY-MM-DD |

---

## 7. Document Revision History

| Version | Date | Author / Role | Summary of Changes |
| :---: | :---: | :--- | :--- |
| `v0.01` | 2026-08-28 | Antigravity AI | Initial functional specification creation. |
| `v0.02` | 2026-08-28 | Antigravity AI | Added Section 2: Immediate Operational Effect Post-Implementation. |
| `v0.03` | 2026-09-02 | Antigravity AI | **Baseline v1.00 Synchronization**: Incorporated Decision 6.1 (same-tx atomic allocation inside `tx.lead.create`, WIB annual reset, and uniqueness-first reconciliation). |
