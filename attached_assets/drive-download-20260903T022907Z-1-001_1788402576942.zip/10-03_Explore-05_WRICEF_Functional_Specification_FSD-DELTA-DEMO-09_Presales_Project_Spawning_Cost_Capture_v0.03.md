# Activate - SPH | WRICEF Functional Specification Document (FSD)

**Document Information**
- **Project Name**: SecureProfit Hub (SPH) Implementation
- **Parent Master FSD**: `10-03_Explore-05_WRICEF_Functional_Specification_FSD_SPH_v0.03.md`
- **Document Identifier**: SPH-FSD-W-DEMO-09
- **WRICEF Title**: Presales Project Auto-Spawning & Cost of Sale Capture
- **WRICEF Type**: Workflow (W)
- **Phase**: 03 - Explore / 04 - Realize
- **Workstream**: Presales Operations & Cost Accounting
- **Sprint Allocation**: Sprint 1 (8 Story Points)
- **Complexity**: Complex
- **Functional Author**: Antigravity AI (Presales Track)
- **Business Process Owner**: Commercial Lead & Delivery Lead
- **Version**: v0.03
- **Status**: Draft (Decision Baseline Synchronized)
- **Date**: 2026-09-02
- **Decision Grounding**: Decision 9.1 (`Answer to - SecureProfit-Hub-Master-Recommendation-All-12-FSD-ID-2026-08.md v1.00`)

---

## 1. Business Requirement & Objective
- **Business Need**: Complex enterprise pursuits incur significant consultant hours and travel expenses during presales scoping. These costs must be tracked for Customer Acquisition Cost (CAC) without contaminating billable delivery Earned Value Management (EVM).
- **User Story**: *As a Commercial Lead & Delivery Principal, I want the option to spawn a presales workspace at the QUALIFIED stage, so that presales hours and travel costs are captured in the CAC ledger.*

---

## 2. Immediate Operational & System Effect Post-Implementation

> [!IMPORTANT]
> **Developer Goal & Operational Target**:
> Provides dedicated presales workspace tracking while maintaining complete isolation between presales CAC costs and delivery EVM baselines.

### Immediate Effects:
1. **Opt-In Workspace Creation**: Spawns an `OBSERVATION` workspace only when explicitly enabled at `QUALIFIED`.
2. **Presales WBS Templates**: Pre-populates scoping, solution demo, and proposal drafting tasks.
3. **Strict CAC Isolation**: Presales timesheets and expenses post to the CAC ledger and are excluded from delivery EVM calculations (`lib/evm.ts`).

---

## 3. Approved Baseline Decisions & Implementation Invariants

* **Decision 9.1 `[APPROVED]`**: Make presales project workspace creation strictly opt-in via a UI toggle at the `QUALIFIED` stage. When enabled, spawn an `OBSERVATION` project workspace with standard presales WBS tasks (Scoping, Proposal Drafting, Pitch). Presales timesheets and expenses are hard-isolated into the Customer Acquisition Cost (CAC) ledger and strictly excluded from delivery EVM calculations.

---

## 4. Test Scenarios & Acceptance Criteria

| Test Case ID | Test Scenario | Expected Result | Pass / Fail |
| :---: | :--- | :--- | :---: |
| **TC-DEMO-09-01** | Opt-in toggle enabled at `QUALIFIED` | Spawns `Project` with `status = OBSERVATION` and presales WBS | [ ] |
| **TC-DEMO-09-02** | Log presales timesheet | Posts to CAC ledger; excluded from project EVM actual cost (`AC`) | [ ] |
| **TC-DEMO-09-03** | Lead marked `LOST` | Presales workspace transitions to `CLOSED`; final CAC summarized | [ ] |

---

## 5. Sign-off and Approvals

| Stakeholder Role | Name & Title | Signature | Date |
| :--- | :--- | :--- | :--- |
| **Commercial Process Owner** | | ____________________ | YYYY-MM-DD |
| **Delivery Process Owner** | | ____________________ | YYYY-MM-DD |
| **Finance Process Owner** | | ____________________ | YYYY-MM-DD |

---

## 6. Document Revision History

| Version | Date | Author / Role | Summary of Changes |
| :---: | :---: | :--- | :--- |
| `v0.01` | 2026-08-28 | Antigravity AI | Initial functional specification creation. |
| `v0.02` | 2026-08-28 | Antigravity AI | Added Section 2: Immediate Operational Effect Post-Implementation. |
| `v0.03` | 2026-09-02 | Antigravity AI | **Baseline v1.00 Synchronization**: Incorporated Decision 9.1 (strictly opt-in presales workspace toggle at `QUALIFIED`, standard presales WBS, and hard isolation of presales timesheets into CAC ledger excluding delivery EVM). |
