# Activate - SPH | WRICEF Functional Specification Document (FSD)

**Document Information**
- **Project Name**: SecureProfit Hub (SPH) Implementation
- **Parent Master FSD**: `10-03_Explore-05_WRICEF_Functional_Specification_FSD_SPH_v0.03.md`
- **Document Identifier**: SPH-FSD-I-DEMO-07
- **WRICEF Title**: Pipedrive Inbound Deal Margin Health Evaluator
- **WRICEF Type**: Interface (I) / Enhancement (E)
- **Phase**: 03 - Explore / 04 - Realize
- **Workstream**: CRM Integration & Margin Governance
- **Sprint Allocation**: Sprint 2 (5 Story Points)
- **Complexity**: Medium
- **Functional Author**: Antigravity AI (Integration Track)
- **Business Process Owner**: Commercial Lead & Finance Lead
- **Version**: v0.03
- **Status**: Draft (Decision Baseline Synchronized)
- **Date**: 2026-09-02
- **Decision Grounding**: Decision 7.1 (`Answer to - SecureProfit-Hub-Master-Recommendation-All-12-FSD-ID-2026-08.md v1.00`)

---

## 1. Business Requirement & Objective
- **Business Need**: Inbound CRM deal synchronizations from Pipedrive must evaluate gross margin health and map external product items accurately to internal offerings, routing unhealthy deals (< 25%) to quarantine.
- **User Story**: *As a Commercial Lead & Finance Lead, I want inbound CRM deals evaluated for gross margin health upon webhook receipt, so that low-margin opportunities are flagged before proposal commit.*

---

## 2. Immediate Operational & System Effect Post-Implementation

> [!IMPORTANT]
> **Developer Goal & Operational Target**:
> Protects portfolio profitability at the intake boundary by filtering and quarantining low-margin deals and unmapped CRM products before synchronization into active pipelines.

### Immediate Effects:
1. **Authoritative Sync Binding**: Webhooks bind strictly to `connectionKey = "DEFAULT"`.
2. **Product Catalog Mapping**: Utilizes `PipedriveProductMapping` composite uniqueness (`[connectionKey, pipedriveProductId]`).
3. **Quarantine Review Workflow**: Automatically quarantines deals with unmapped products or margin $< 25\%$, notifying Commercial Ops.

---

## 3. Approved Baseline Decisions & Implementation Invariants

* **Decision 7.1 `[APPROVED]`**: Bind inbound CRM webhooks to an authoritative configuration (`connectionKey = "DEFAULT"`). Map external CRM products to internal catalog offerings via `PipedriveProductMapping` with composite uniqueness (`[connectionKey, pipedriveProductId]`). Route deals with missing mappings or gross margin $< 25\%$ to a quarantined review queue.

---

## 4. Target Data Model & Mapping Architecture

```prisma
model PipedriveProductMapping {
  id                  String           @id @default(cuid())
  connectionKey       String           @default("DEFAULT")
  pipedriveProductId  String
  offeringCatalogId   String
  offeringCatalog     OfferingCatalog  @relation(fields: [offeringCatalogId], references: [id])
  createdAt           DateTime         @default(now())

  @@unique([connectionKey, pipedriveProductId])
}
```

---

## 5. Test Scenarios & Acceptance Criteria

| Test Case ID | Test Scenario | Expected Result | Pass / Fail |
| :---: | :--- | :--- | :---: |
| **TC-DEMO-07-01** | Inbound deal with margin $\ge 25\%$ | Syncs cleanly into active Leads pipeline | [ ] |
| **TC-DEMO-07-02** | Inbound deal with margin $< 25\%$ | Deal flagged; routed to quarantine review queue; alert sent | [ ] |
| **TC-DEMO-07-03** | Unmapped external product | Webhook creates quarantine entry requesting product mapping | [ ] |

---

## 6. Sign-off and Approvals

| Stakeholder Role | Name & Title | Signature | Date |
| :--- | :--- | :--- | :--- |
| **Commercial Process Owner** | | ____________________ | YYYY-MM-DD |
| **Finance Process Owner** | | ____________________ | YYYY-MM-DD |

---

## 7. Document Revision History

| Version | Date | Author / Role | Summary of Changes |
| :---: | :---: | :--- | :--- |
| `v0.01` | 2026-08-28 | Antigravity AI | Initial functional specification creation. |
| `v0.02` | 2026-08-28 | Antigravity AI | Added Section 2: Immediate Operational Effect Post-Implementation. |
| `v0.03` | 2026-09-02 | Antigravity AI | **Baseline v1.00 Synchronization**: Incorporated Decision 7.1 (authoritative `connectionKey = "DEFAULT"`, `PipedriveProductMapping` composite key, and $< 25\%$ margin quarantine path). |
