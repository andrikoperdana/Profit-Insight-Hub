/**
 * Standalone production server for Expo static builds.
 *
 * Serves the output of build.js (static-build/) with two special routes:
 * - GET / or /manifest with expo-platform header → platform manifest JSON
 * - GET / without expo-platform → landing page HTML
 * Everything else falls through to static file serving from ./static-build/.
 *
 * Zero external dependencies — uses only Node.js built-ins (http, fs, path).
 */

const http = require("http");
const fs = require("fs");
const path = require("path");

const STATIC_ROOT = path.resolve(__dirname, "..", "static-build");
const TEMPLATE_PATH = path.resolve(__dirname, "templates", "landing-page.html");
const basePath = (process.env.BASE_PATH || "/").replace(/\/+$/, "");

const MIME_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".gif": "image/gif",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
  ".ttf": "font/ttf",
  ".otf": "font/otf",
  ".map": "application/json",
};

function getAppName() {
  try {
    const appJsonPath = path.resolve(__dirname, "..", "app.json");
    const appJson = JSON.parse(fs.readFileSync(appJsonPath, "utf-8"));
    return appJson.expo?.name || "App Landing Page";
  } catch {
    return "App Landing Page";
  }
}

function serveManifest(platform, res) {
  const manifestPath = path.join(STATIC_ROOT, platform, "manifest.json");

  if (!fs.existsSync(manifestPath)) {
    res.writeHead(404, { "content-type": "application/json" });
    res.end(
      JSON.stringify({ error: `Manifest not found for platform: ${platform}` }),
    );
    return;
  }

  const manifest = fs.readFileSync(manifestPath, "utf-8");
  res.writeHead(200, {
    "content-type": "application/json",
    "expo-protocol-version": "1",
    "expo-sfv-version": "0",
  });
  res.end(manifest);
}

// Only allow RFC 3986 host[:port] characters: hostname labels
// (alphanumeric, dots, hyphens) with an optional numeric port.
const VALID_HOST_RE = /^[a-zA-Z0-9.-]+(:\d{1,5})?$/;

// Explicit allowlist of hosts this server may reflect into the landing
// page. Built from deployment/environment configuration, never from
// request data. ALLOWED_HOSTS is a comma-separated override/extension.
function buildAllowedHosts() {
  const hosts = new Set();
  const add = (value) => {
    if (typeof value !== "string") return;
    for (const entry of value.split(",")) {
      const h = entry.trim().toLowerCase();
      if (h && VALID_HOST_RE.test(h)) {
        hosts.add(h);
        // Also allow the bare hostname without an explicit port.
        hosts.add(h.replace(/:\d+$/, ""));
      }
    }
  };
  add(process.env.ALLOWED_HOSTS);
  add(process.env.REPLIT_DOMAINS);
  add(process.env.REPLIT_DEV_DOMAIN);
  add(process.env.REPLIT_EXPO_DEV_DOMAIN);
  add("localhost");
  add("127.0.0.1");
  return hosts;
}

const ALLOWED_HOSTS = buildAllowedHosts();

// Returns the canonical (lowercased, trimmed) host[:port] string if the
// value is syntactically valid AND its hostname is on the allowlist;
// otherwise null.
function sanitizeHost(rawHost, allowedHosts = ALLOWED_HOSTS) {
  const raw = Array.isArray(rawHost) ? rawHost[0] : rawHost;
  if (typeof raw !== "string") return null;
  const host = raw.trim().toLowerCase();
  if (!VALID_HOST_RE.test(host)) return null;
  const hostname = host.replace(/:\d+$/, "");
  if (!allowedHosts.has(host) && !allowedHosts.has(hostname)) return null;
  return host;
}

function serveLandingPage(req, res, landingPageTemplate, appName) {
  const forwardedProto = req.headers["x-forwarded-proto"];
  const protocol = forwardedProto === "http" ? "http" : "https";
  const host =
    sanitizeHost(req.headers["x-forwarded-host"]) ||
    sanitizeHost(req.headers["host"]);

  if (!host) {
    res.writeHead(400, { "content-type": "text/plain; charset=utf-8" });
    res.end("Bad Request: invalid Host header");
    return;
  }

  const baseUrl = `${protocol}://${host}`;
  const expsUrl = `${host}`;

  const html = landingPageTemplate
    .replace(/BASE_URL_PLACEHOLDER/g, baseUrl)
    .replace(/EXPS_URL_PLACEHOLDER/g, expsUrl)
    .replace(/APP_NAME_PLACEHOLDER/g, appName);

  res.writeHead(200, { "content-type": "text/html; charset=utf-8" });
  res.end(html);
}

function serveStaticFile(urlPath, res) {
  const safePath = path.normalize(urlPath).replace(/^(\.\.(\/|\\|$))+/, "");
  const filePath = path.join(STATIC_ROOT, safePath);

  if (!filePath.startsWith(STATIC_ROOT)) {
    res.writeHead(403);
    res.end("Forbidden");
    return;
  }

  if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    res.writeHead(404);
    res.end("Not Found");
    return;
  }

  const ext = path.extname(filePath).toLowerCase();
  const contentType = MIME_TYPES[ext] || "application/octet-stream";
  const content = fs.readFileSync(filePath);
  res.writeHead(200, { "content-type": contentType });
  res.end(content);
}

const landingPageTemplate = fs.readFileSync(TEMPLATE_PATH, "utf-8");
const appName = getAppName();

const server = http.createServer((req, res) => {
  const url = new URL(req.url || "/", `http://${req.headers.host}`);
  let pathname = url.pathname;

  if (basePath && pathname.startsWith(basePath)) {
    pathname = pathname.slice(basePath.length) || "/";
  }

  if (pathname === "/" || pathname === "/manifest") {
    const platform = req.headers["expo-platform"];
    if (platform === "ios" || platform === "android") {
      return serveManifest(platform, res);
    }

    if (pathname === "/") {
      return serveLandingPage(req, res, landingPageTemplate, appName);
    }
  }

  serveStaticFile(pathname, res);
});

const port = parseInt(process.env.PORT || "3000", 10);
server.listen(port, "0.0.0.0", () => {
  console.log(`Serving static Expo build on port ${port}`);
});
