import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Clock, Hourglass } from "lucide-react";
import itsecLogo from "@assets/Logo_ITSEC_RedE_White.png";
import itsecLogoDark from "@assets/Logo_ITSEC_RedE_Dark.png";
import { useLocation } from "wouter";
import { useEffect, useRef, useState } from "react";
import {
  useLogin,
  useGoogleLogin,
  useGetGoogleAuthConfig,
  getGetGoogleAuthConfigQueryKey,
} from "@workspace/api-client-react";
import { useAuth } from "@/lib/auth";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { consumeSessionExpired, consumePostLoginRedirect } from "@/lib/session";

import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

const loginSchema = z.object({
  email: z.string().email({ message: "Invalid email address" }),
  password: z.string().min(1, { message: "Password is required" }),
});

type LoginFormValues = z.infer<typeof loginSchema>;

export default function Login() {
  const { login: setAuth, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  // Read-and-clear once on mount so the notice shows after an expiry redirect
  // and the remembered destination survives effect re-runs (the helpers are
  // destructive read-and-clear, so they must only be called once).
  const [sessionExpired] = useState(() => consumeSessionExpired());
  const [postLoginRedirect] = useState(() => consumePostLoginRedirect());

  useEffect(() => {
    if (isAuthenticated) setLocation(postLoginRedirect);
  }, [isAuthenticated, setLocation, postLoginRedirect]);
  
  const form = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const loginMutation = useLogin({
    mutation: {
      onSuccess: (data) => {
        setAuth(data.token, data.user);
      },
      onError: (error: any) => {
        toast({
          variant: "destructive",
          title: "Login failed",
          description: error?.message || "Please check your credentials and try again.",
        });
      },
    },
  });

  const onSubmit = (data: LoginFormValues) => {
    loginMutation.mutate({ data });
  };

  // ---- Google SSO (Google Identity Services ID-token flow) ----
  // The client ID is served by the API (public by design); when it is null the
  // Google button is hidden entirely and password login is unaffected.
  const { data: googleConfig } = useGetGoogleAuthConfig({
    query: { queryKey: getGetGoogleAuthConfigQueryKey(), staleTime: Infinity },
  });
  const googleClientId = googleConfig?.clientId ?? null;
  const googleBtnRef = useRef<HTMLDivElement>(null);
  const [ssoPending, setSsoPending] = useState(false);

  const googleLoginMutation = useGoogleLogin({
    mutation: {
      onSuccess: (data) => {
        if (data.status === "AUTHENTICATED" && data.token && data.user) {
          setAuth(data.token, data.user);
          return;
        }
        setSsoPending(true);
        toast({
          title: "Access request submitted",
          description: "A Site Admin must approve your request before you can sign in.",
        });
      },
      onError: (error: any) => {
        toast({
          variant: "destructive",
          title: "Google sign-in failed",
          description: error?.message || "Please try again or use your password.",
        });
      },
    },
  });
  // `mutate` is referenced from the GIS callback registered once below; keep a
  // ref so the callback never captures a stale closure.
  const googleMutateRef = useRef(googleLoginMutation.mutate);
  googleMutateRef.current = googleLoginMutation.mutate;

  useEffect(() => {
    if (!googleClientId) return;
    let cancelled = false;

    const render = () => {
      const google = (window as any).google;
      if (cancelled || !google?.accounts?.id || !googleBtnRef.current) return;
      google.accounts.id.initialize({
        client_id: googleClientId,
        callback: (resp: { credential?: string }) => {
          if (resp?.credential) {
            googleMutateRef.current({ data: { credential: resp.credential } });
          }
        },
      });
      google.accounts.id.renderButton(googleBtnRef.current, {
        theme: "filled_black",
        size: "large",
        text: "signin_with",
        shape: "rect",
        logo_alignment: "left",
        width: 320,
      });
    };

    if ((window as any).google?.accounts?.id) {
      render();
      return () => { cancelled = true; };
    }
    const src = "https://accounts.google.com/gsi/client";
    let script = document.querySelector<HTMLScriptElement>(`script[src="${src}"]`);
    if (!script) {
      script = document.createElement("script");
      script.src = src;
      script.async = true;
      script.defer = true;
      document.head.appendChild(script);
    }
    script.addEventListener("load", render);
    return () => {
      cancelled = true;
      script?.removeEventListener("load", render);
    };
  }, [googleClientId]);

  const seedUsers = [
    { email: "superadmin@itsecasia.com", role: "Super Admin" },
    { email: "management@itsecasia.com", role: "PMO Director" },
    { email: "pm@itsecasia.com", role: "Project Manager" },
    { email: "sales@itsecasia.com", role: "Sales" },
    { email: "konsultan@itsecasia.com", role: "Consultant" },
    { email: "writer@itsecasia.com", role: "Technical Writer" },
    { email: "admin@itsecasia.com", role: "Admin Project" },
    { email: "principal.kon.h7q4@itsecasia.com", role: "Principal Consultant" },
    { email: "principal.tw.m9k2@itsecasia.com", role: "Principal Technical Writer" },
    { email: "principal.ap.r3n8@itsecasia.com", role: "Principal Admin Project" },
    { email: "finance@itsecasia.com", role: "Finance" },
    { email: "hr@itsecasia.com", role: "HR" },
    { email: "siteadmin@itsecasia.com", role: "Site Admin" },
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col justify-center items-center p-4 relative overflow-hidden">
      {/* Cyberpunk grid background effect */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none"></div>
      
      <div className="z-10 w-full max-w-md space-y-8">
        <div className="flex flex-col items-center justify-center space-y-2 text-center">
          <img src={itsecLogoDark} alt="ITSEC — Cybersecurity Delivered" className="h-16 w-auto mb-2 block dark:hidden" />
          <img src={itsecLogo} alt="ITSEC — Cybersecurity Delivered" className="h-16 w-auto mb-2 hidden dark:block" />
          <h1 className="text-xl font-bold tracking-tight text-foreground">SecureProfit Hub</h1>
          <p className="text-muted-foreground text-sm">IT Security Projects, Operations & Margins Console</p>
        </div>

        {sessionExpired && (
          <Alert className="bg-card/80 backdrop-blur-sm border-primary/30">
            <Clock className="h-4 w-4" />
            <AlertTitle>Session expired</AlertTitle>
            <AlertDescription>
              Your session has ended. Please sign in again to continue.
            </AlertDescription>
          </Alert>
        )}

        {ssoPending && (
          <Alert className="bg-card/80 backdrop-blur-sm border-primary/30" data-testid="alert-sso-pending">
            <Hourglass className="h-4 w-4" />
            <AlertTitle>Awaiting approval</AlertTitle>
            <AlertDescription>
              Your access request has been submitted. A Site Admin will review it —
              once approved you can sign in with Google.
            </AlertDescription>
          </Alert>
        )}

        <Card className="border-border/50 shadow-xl bg-card/80 backdrop-blur-sm">
          <CardHeader>
            <CardTitle>System Access</CardTitle>
            <CardDescription>Enter your credentials to continue</CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input placeholder="user@itsecasia.com" {...field} className="bg-background" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder="••••••••" {...field} className="bg-background" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button 
                  type="submit" 
                  className="w-full font-bold shadow-[0_0_10px_rgba(22,163,74,0.4)]" 
                  disabled={loginMutation.isPending}
                >
                  {loginMutation.isPending ? "Authenticating..." : "Initialize Session"}
                </Button>
              </form>
            </Form>

            {googleClientId && (
              <>
                <div className="relative my-4">
                  <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t border-border/60" />
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-card px-2 text-muted-foreground">or</span>
                  </div>
                </div>
                <div className="flex justify-center" data-testid="button-google-signin">
                  <div ref={googleBtnRef} />
                </div>
                {googleLoginMutation.isPending && (
                  <p className="mt-2 text-center text-xs text-muted-foreground">
                    Signing in with Google…
                  </p>
                )}
              </>
            )}
          </CardContent>
        </Card>

        <Card className="border-border/30 bg-muted/30">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-muted-foreground tracking-wider"><span className="uppercase">Test Credentials</span> (password: password123)</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-2 gap-2 text-xs">
            {seedUsers.map((u) => (
              <div 
                key={u.email} 
                className="p-2 rounded border border-border/50 bg-background/50 cursor-pointer hover:border-primary/50 transition-colors"
                onClick={() => {
                  form.setValue("email", u.email);
                  form.setValue("password", "password123");
                }}
              >
                <div className="font-semibold text-primary">{u.role}</div>
                <div className="text-muted-foreground truncate" title={u.email}>{u.email}</div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
