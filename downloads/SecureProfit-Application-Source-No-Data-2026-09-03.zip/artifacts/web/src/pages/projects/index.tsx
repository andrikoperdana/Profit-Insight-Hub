import { useListProjects, customFetch } from "@workspace/api-client-react";
import { Link } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Plus, Search, Download, FileText } from "lucide-react";
import { formatMoney } from "@/lib/format";
import { useAuth } from "@/lib/auth";
import { canCreateProject, canViewProjectFinancials } from "@/lib/roles";
import { exportSheets, exportCsv } from "@/lib/exports";
import { classifyProject } from "@workspace/shared";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card } from "@/components/ui/card";
import { TableSkeleton } from "@/components/common/Loading";
import { EmptyState } from "@/components/common/EmptyState";
import { Pagination, usePagination } from "@/components/common/Pagination";
import { HealthBadge, MarginBadge, ProjectStatusBadge } from "@/components/common/Badges";
import { ProjectStatus } from "@workspace/api-client-react";

export default function ProjectsList() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const isPrincipal = !!user?.role && user.role.startsWith("PRINCIPAL_");
  // Principals only see ACTIVE projects (server-enforced), so lock the
  // status filter and hide the other status tabs.
  const [statusFilter, setStatusFilter] = useState<string>(
    isPrincipal ? ProjectStatus.ACTIVE : "all",
  );
  const [searchQuery, setSearchQuery] = useState("");
  const [pmFilter, setPmFilter] = useState<string>("all");
  const [seeding, setSeeding] = useState(false);

  const isMgmt = user?.role === "MANAGEMENT" || user?.role === "SUPER_ADMIN";
  const isArchivedTab = statusFilter === "archived";
  const { data: rawProjects, isLoading } = useListProjects(
    isArchivedTab
      ? { includeArchived: "true" }
      : statusFilter === "all"
        ? {}
        : { status: statusFilter },
    { query: { queryKey: ["projects", statusFilter] } }
  );
  // The Archived tab loads everything (incl. archived) and keeps only archived
  // rows; other tabs already exclude archived server-side.
  const projects = isArchivedTab
    ? rawProjects?.filter((p) => !!p.archivedAt)
    : rawProjects;

  const nonClosedCount = (projects ?? []).filter(p => p.status !== "CLOSED" && p.status !== "COMPLETE").length;
  const showSeed = !import.meta.env.PROD && user?.role === "MANAGEMENT" && statusFilter === "all" && nonClosedCount < 3;
  const onSeed = async () => {
    if (!confirm("Add 9 sample projects (3 OBSERVATION + 3 ACTIVE + 3 PAUSE)?")) return;
    setSeeding(true);
    try {
      const r = await customFetch("/api/projects/seed-demo", { method: "POST" }) as { created?: unknown[]; skipped?: unknown[] };
      alert(`Success. Created: ${r.created?.length ?? 0}, skipped: ${r.skipped?.length ?? 0}.`);
      queryClient.invalidateQueries();
    } catch (e: unknown) {
      alert(`Failed: ${e instanceof Error ? e.message : String(e)}`);
    } finally {
      setSeeding(false);
    }
  };

  const filteredProjects = projects?.filter(p => {
    const q = searchQuery.toLowerCase();
    return (
      p.name.toLowerCase().includes(q) ||
      (p.code?.toLowerCase().includes(q) ?? false) ||
      (p.projectId?.toLowerCase().includes(q) ?? false) ||
      (p.clientName?.toLowerCase().includes(q) ?? false)
    );
  })?.filter(p => pmFilter === "all" || p.pmId === pmFilter);

  // Distinct PMs present in the loaded (status-scoped) project set, for the
  // "Filter by PM" dropdown next to the search box. Lets MGMT/Super Admin slice
  // the list by who owns each engagement without a server round-trip.
  const pmOptions = Array.from(
    (projects ?? []).reduce((m, p) => {
      if (p.pmId && p.pmName) m.set(p.pmId, p.pmName);
      return m;
    }, new Map<string, string>()),
  )
    .map(([id, name]) => ({ id, name }))
    .sort((a, b) => a.name.localeCompare(b.name));

  const showFinancials = canViewProjectFinancials(user?.role);

  const projectExportRows = (filteredProjects ?? []).map((p) => {
    const base: Record<string, unknown> = {
      ProjectID: p.projectId ?? "",
      SPK_PO: p.code ?? "",
      Name: p.name,
      Type: classifyProject({ name: p.name, code: p.projectId ?? p.code ?? "" }),
      Client: p.clientName ?? "",
      PM: p.pmName ?? "",
      Sales: p.salesName ?? "",
      Status: p.status,
    };
    if (showFinancials) {
      base.ContractValue = p.contractValue;
      base.EstimatedCost = p.estimatedCost ?? 0;
      base.EstimatedProfit = p.estimatedProfit ?? 0;
      base.ActualCost = p.actualCost ?? 0;
      base.ActualProfit = p.actualProfit ?? 0;
      base.MarginPct = p.marginPct;
    }
    base.PlannedMandays = p.plannedMandays ?? 0;
    base.ActualMandays = p.actualMandays ?? 0;
    base.StartDate = p.startDate ?? "";
    base.EndDate = p.endDate ?? "";
    return base;
  });

  const pager = usePagination(filteredProjects, {
    resetKey: `${statusFilter}|${searchQuery}|${pmFilter}`,
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Projects</h1>
          <p className="text-muted-foreground">Manage active consulting engagements.</p>
        </div>
        
        <div className="flex gap-2 shrink-0 flex-wrap">
          <Button
            variant="outline"
            onClick={() => exportCsv("projects", projectExportRows)}
            disabled={projectExportRows.length === 0}
            data-testid="button-export-projects-csv"
          >
            <Download className="h-4 w-4 mr-2" /> CSV
          </Button>
          <Button
            variant="outline"
            onClick={() => exportSheets("project-profitability", [{ name: "Projects", rows: projectExportRows }])}
            disabled={projectExportRows.length === 0}
            data-testid="button-export-projects"
          >
            <Download className="h-4 w-4 mr-2" /> XLSX
          </Button>
          {showSeed && (
            <Button variant="outline" onClick={onSeed} disabled={seeding} data-testid="button-seed-projects-demo">
              {seeding ? "Seeding…" : "Load 9 demo projects"}
            </Button>
          )}
          {canCreateProject(user?.role) && user?.role !== "SALES" && (
            <Button asChild>
              <Link href="/projects/new">
                <Plus className="h-4 w-4 mr-2" /> New Project
              </Link>
            </Button>
          )}
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 justify-between items-center">
        <Tabs value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setPmFilter("all"); }} className="w-full sm:w-auto">
          <TabsList className="bg-muted w-full sm:w-auto overflow-x-auto justify-start">
            {!isPrincipal && <TabsTrigger value="all">All</TabsTrigger>}
            {!isPrincipal && <TabsTrigger value={ProjectStatus.OBSERVATION}>Observation</TabsTrigger>}
            <TabsTrigger value={ProjectStatus.ACTIVE}>Active</TabsTrigger>
            {!isPrincipal && <TabsTrigger value={ProjectStatus.PAUSE}>Pause</TabsTrigger>}
            {!isPrincipal && <TabsTrigger value={ProjectStatus.COMPLETE}>Complete</TabsTrigger>}
            {!isPrincipal && <TabsTrigger value={ProjectStatus.CLOSED}>Closed</TabsTrigger>}
            {isMgmt && <TabsTrigger value="archived" data-testid="tab-archived">Archived</TabsTrigger>}
          </TabsList>
        </Tabs>

        <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
          {pmOptions.length >= 2 && (
            <Select value={pmFilter} onValueChange={setPmFilter}>
              <SelectTrigger className="w-full sm:w-48 bg-card" data-testid="select-pm-filter">
                <SelectValue placeholder="Filter by PM" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All PMs</SelectItem>
                {pmOptions.map((pm) => (
                  <SelectItem key={pm.id} value={pm.id}>{pm.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search projects..." 
            className="pl-9 bg-card" 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        </div>
      </div>

      {isLoading ? (
        <TableSkeleton columns={6} rows={10} />
      ) : !filteredProjects?.length ? (
        <EmptyState 
          title="No projects found" 
          description={searchQuery ? "No projects match your search." : "There are no projects in this status."}
        />
      ) : (
        <Card className="overflow-hidden border-border shadow-sm">
          <Table>
            <TableHeader className="bg-muted/50">
              <TableRow>
                <TableHead>Project</TableHead>
                <TableHead>Client</TableHead>
                <TableHead>Status</TableHead>
                {showFinancials && (
                  <>
                    <TableHead className="text-right">Contract Value</TableHead>
                    <TableHead className="text-center">Margin</TableHead>
                    <TableHead className="text-center">Health</TableHead>
                  </>
                )}
                <TableHead className="text-right">PM</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {pager.pageItems.map((project) => (
                <TableRow key={project.id} className="group cursor-pointer hover:bg-muted/30">
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Link href={`/projects/${project.id}`} className="block min-w-0 outline-none">
                        <div className="font-medium text-foreground group-hover:text-primary transition-colors">{project.name}</div>
                        <div className="text-xs text-muted-foreground font-mono">
                          {project.projectId ?? project.code}
                          {project.projectId && project.code && (
                            <span className="ml-1 text-muted-foreground/60">· {project.code}</span>
                          )}
                        </div>
                      </Link>
                      <Button
                        asChild
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7 shrink-0 text-muted-foreground hover:text-foreground"
                        title="Open project summary"
                        data-testid={`button-project-summary-${project.id}`}
                      >
                        <Link href={`/projects/${project.id}/summary`} aria-label="Open project summary">
                          <FileText className="h-4 w-4" />
                        </Link>
                      </Button>
                    </div>
                  </TableCell>
                  <TableCell>{project.clientName || "-"}</TableCell>
                  <TableCell><ProjectStatusBadge status={project.status} /></TableCell>
                  {showFinancials && (
                    <>
                      <TableCell className="text-right font-mono text-sm">
                        {formatMoney(project.contractValue, project.currency ?? undefined)}
                        {project.currency && project.currency !== "IDR" && (
                          <span className="ml-1 text-[10px] uppercase text-muted-foreground">{project.currency}</span>
                        )}
                      </TableCell>
                      <TableCell className="text-center"><MarginBadge marginPct={project.marginPct} /></TableCell>
                      <TableCell className="text-center">
                        <HealthBadge
                          score={project.healthScore ?? null}
                          label={project.healthLabel ?? null}
                          reasons={project.healthReasons ?? null}
                          components={(project.healthComponents as import("@/components/common/Badges").HealthComponents) ?? null}
                        />
                      </TableCell>
                    </>
                  )}
                  <TableCell className="text-right text-muted-foreground text-sm">{project.pmName || "-"}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <Pagination
            page={pager.page}
            pageSize={pager.pageSize}
            total={pager.total}
            totalPages={pager.totalPages}
            onPageChange={pager.setPage}
            onPageSizeChange={pager.setPageSize}
            testId="projects-pagination"
          />
        </Card>
      )}
    </div>
  );
}
