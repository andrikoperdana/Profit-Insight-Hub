import { useState, useEffect } from "react";
import { useAuth } from "@/lib/auth";
import { canManageUsers, canViewAllUsers, RoleLabels, isPrincipalRole, PRINCIPAL_TO_REPORT_ROLE } from "@/lib/roles";
import {
  useListUsers,
  useCreateUser,
  useUpdateUser,
  useListBusinessUnits,
  useListSkills,
} from "@workspace/api-client-react";
import { getListUsersQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Plus, ShieldAlert, Pencil, Download, Briefcase } from "lucide-react";
import { Link } from "wouter";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useToast } from "@/hooks/use-toast";
import { formatIDR } from "@/lib/format";
import { UserRole } from "@workspace/api-client-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { TableSkeleton } from "@/components/common/Loading";
import { EmptyState } from "@/components/common/EmptyState";
import { Pagination, usePagination } from "@/components/common/Pagination";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Checkbox } from "@/components/ui/checkbox";
import { ScrollArea } from "@/components/ui/scroll-area";

const NONE = "__none__";

const userSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  role: z.nativeEnum(UserRole),
  title: z.string().optional(),
  dailyRate: z.coerce.number().min(0).optional(),
  managerId: z.string().optional(),
  principalId: z.string().optional(),
  seniority: z.string().optional(),
  businessUnitId: z.string().optional(),
});

type UserFormValues = z.infer<typeof userSchema>;

const editUserSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  role: z.nativeEnum(UserRole),
  title: z.string().optional(),
  dailyRate: z.coerce.number().min(0).optional(),
  password: z.string().optional().refine(
    (v) => !v || v.length >= 6,
    { message: "Password must be at least 6 characters" }
  ),
  managerId: z.string().optional(),
  principalId: z.string().optional(),
  seniority: z.string().optional(),
  businessUnitId: z.string().optional(),
});

type EditUserFormValues = z.infer<typeof editUserSchema>;

const SENIORITY_OPTIONS: { value: string; label: string }[] = [
  { value: "JUNIOR", label: "Junior" },
  { value: "MID", label: "Mid" },
  { value: "SENIOR", label: "Senior" },
  { value: "PRINCIPAL", label: "Principal" },
];

type UserRow = {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  title?: string | null;
  dailyRate?: number | null;
  isActive: boolean;
  managerId?: string | null;
  principalId?: string | null;
};

// Which Principal role supervises a given delivery role.
const PRINCIPAL_FOR_ROLE: Partial<Record<UserRole, UserRole>> = {
  [UserRole.KONSULTAN]: UserRole.PRINCIPAL_KONSULTAN,
  [UserRole.TECHNICAL_WRITER]: UserRole.PRINCIPAL_TECHNICAL_WRITER,
  [UserRole.ADMIN_PROJECT]: UserRole.PRINCIPAL_ADMIN_PROJECT,
};

function csvEscape(value: unknown): string {
  if (value === null || value === undefined) return "";
  let s = String(value);
  // Neutralize spreadsheet formula injection (=, +, -, @, tab, CR)
  if (s.length > 0 && /^[=+\-@\t\r]/.test(s)) {
    s = "'" + s;
  }
  if (s.includes(",") || s.includes('"') || s.includes("\n") || s.includes("\r")) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}

function downloadUsersCsv(users: UserRow[]) {
  const headers = ["Name", "Email", "Role", "Title", "Daily Rate (IDR)", "Status"];
  const rows = users.map((u) => [
    u.name,
    u.email,
    RoleLabels[u.role] ?? u.role,
    u.title ?? "",
    u.dailyRate ?? "",
    u.isActive ? "Active" : "Inactive",
  ]);
  const csv = [headers, ...rows]
    .map((row) => row.map(csvEscape).join(","))
    .join("\r\n");
  const bom = "\uFEFF";
  const blob = new Blob([bom + csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  const date = new Date().toISOString().slice(0, 10);
  a.href = url;
  a.download = `personnel-${date}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export default function UsersList() {
  const { user: currentUser } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<UserRow | null>(null);
  // Reverse-link selections for MGMT (their PMs) and Principals (their supervisees).
  const [reportPmIds, setReportPmIds] = useState<string[]>([]);
  const [superviseeIds, setSuperviseeIds] = useState<string[]>([]);
  const [initialReportPmIds, setInitialReportPmIds] = useState<string[]>([]);
  const [initialSuperviseeIds, setInitialSuperviseeIds] = useState<string[]>([]);
  const [createSkillIds, setCreateSkillIds] = useState<string[]>([]);
  const [editSkillIds, setEditSkillIds] = useState<string[]>([]);
  const { data: businessUnits } = useListBusinessUnits();
  const { data: skillsCatalog } = useListSkills();

  const { data: users, isLoading } = useListUsers({
    query: { queryKey: getListUsersQueryKey() }
  });

  const createUser = useCreateUser({
    mutation: {
      onSuccess: () => {
        toast({ title: "User created successfully" });
        queryClient.invalidateQueries({ queryKey: getListUsersQueryKey() });
        setIsCreateOpen(false);
        form.reset();
      },
      onError: (err: any) => {
        toast({ variant: "destructive", title: "Failed to create user", description: err.message });
      }
    }
  });

  const updateUser = useUpdateUser({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListUsersQueryKey() });
      },
      onError: (err: any) => {
        toast({ variant: "destructive", title: "Failed to update user", description: err.message });
      }
    }
  });

  const editUserMutation = useUpdateUser({
    mutation: {
      onSuccess: () => {
        toast({ title: "User updated successfully" });
        queryClient.invalidateQueries({ queryKey: getListUsersQueryKey() });
        setEditingUser(null);
      },
      onError: (err: any) => {
        toast({ variant: "destructive", title: "Failed to update user", description: err.message });
      }
    }
  });

  const form = useForm<UserFormValues>({
    resolver: zodResolver(userSchema),
    defaultValues: { name: "", email: "", password: "password123", role: UserRole.KONSULTAN, title: "", dailyRate: 0, managerId: NONE, principalId: NONE, seniority: NONE, businessUnitId: NONE }
  });

  const editForm = useForm<EditUserFormValues>({
    resolver: zodResolver(editUserSchema),
    defaultValues: { name: "", role: UserRole.KONSULTAN, title: "", dailyRate: 0, password: "", managerId: NONE, principalId: NONE, seniority: NONE, businessUnitId: NONE }
  });

  useEffect(() => {
    if (editingUser) {
      editForm.reset({
        name: editingUser.name,
        role: editingUser.role,
        title: editingUser.title ?? "",
        dailyRate: editingUser.dailyRate ?? 0,
        password: "",
        managerId: editingUser.managerId ?? NONE,
        principalId: editingUser.principalId ?? NONE,
        seniority: ((editingUser as any).seniority as string | null | undefined) ?? NONE,
        businessUnitId: ((editingUser as any).businessUnitId as string | null | undefined) ?? NONE,
      });
      const existingSkills = ((editingUser as any).skills as Array<{ skillId: string }> | undefined) ?? [];
      setEditSkillIds(existingSkills.map((s) => s.skillId));
      // Seed reverse-link state from current users data.
      const allUsers = (users ?? []) as any[];
      if (editingUser.role === UserRole.MANAGEMENT) {
        const pms = allUsers
          .filter((u) => u.role === UserRole.PROJECT_MANAGER && u.managerId === editingUser.id)
          .map((u) => u.id);
        setReportPmIds(pms);
        setInitialReportPmIds(pms);
      } else {
        setReportPmIds([]);
        setInitialReportPmIds([]);
      }
      const reportRole = PRINCIPAL_TO_REPORT_ROLE[editingUser.role as UserRole];
      if (reportRole) {
        const sup = allUsers
          .filter((u) => u.role === reportRole && u.principalId === editingUser.id)
          .map((u) => u.id);
        setSuperviseeIds(sup);
        setInitialSuperviseeIds(sup);
      } else {
        setSuperviseeIds([]);
        setInitialSuperviseeIds([]);
      }
    }
  }, [editingUser, editForm, users]);

  // Pools used to populate Manager / Principal selectors.
  const managers = (users ?? []).filter((u: any) => u.role === UserRole.MANAGEMENT && u.isActive);
  const principalsByRole = (role: UserRole | undefined) => {
    const principalRole = role ? PRINCIPAL_FOR_ROLE[role] : undefined;
    if (!principalRole) return [] as any[];
    return (users ?? []).filter((u: any) => u.role === principalRole && u.isActive);
  };

  const onSubmit = (data: UserFormValues) => {
    const payload: Record<string, unknown> = {
      name: data.name,
      email: data.email,
      password: data.password,
      role: data.role,
      title: data.title || undefined,
      dailyRate: data.dailyRate ?? 0,
    };
    if (data.role === UserRole.PROJECT_MANAGER) {
      payload.managerId = data.managerId && data.managerId !== NONE ? data.managerId : null;
    }
    if (PRINCIPAL_FOR_ROLE[data.role]) {
      payload.principalId = data.principalId && data.principalId !== NONE ? data.principalId : null;
    }
    payload.seniority = data.seniority && data.seniority !== NONE ? data.seniority : null;
    payload.businessUnitId = data.businessUnitId && data.businessUnitId !== NONE ? data.businessUnitId : null;
    payload.skillIds = createSkillIds;
    createUser.mutate({ data: payload as any }, {
      onSuccess: () => setCreateSkillIds([]),
    });
  };

  const onEditSubmit = async (data: EditUserFormValues) => {
    if (!editingUser) return;
    const payload: Record<string, unknown> = {
      name: data.name,
      role: data.role,
      title: data.title || null,
      dailyRate: data.dailyRate ?? 0,
    };
    if (data.password && data.password.length > 0) {
      payload.password = data.password;
    }
    payload.managerId = data.role === UserRole.PROJECT_MANAGER && data.managerId && data.managerId !== NONE
      ? data.managerId
      : null;
    payload.principalId = PRINCIPAL_FOR_ROLE[data.role] && data.principalId && data.principalId !== NONE
      ? data.principalId
      : null;
    payload.seniority = data.seniority && data.seniority !== NONE ? data.seniority : null;
    payload.businessUnitId = data.businessUnitId && data.businessUnitId !== NONE ? data.businessUnitId : null;
    payload.skillIds = editSkillIds;
    try {
      await editUserMutation.mutateAsync({ id: editingUser.id, data: payload as any });
      // Apply reverse-link diffs (MGMT → PMs.managerId; Principal → reports.principalId).
      const ops: Promise<unknown>[] = [];
      if (data.role === UserRole.MANAGEMENT) {
        const added = reportPmIds.filter((id) => !initialReportPmIds.includes(id));
        const removed = initialReportPmIds.filter((id) => !reportPmIds.includes(id));
        for (const id of added) {
          ops.push(updateUser.mutateAsync({ id, data: { managerId: editingUser.id } as any }));
        }
        for (const id of removed) {
          ops.push(updateUser.mutateAsync({ id, data: { managerId: null } as any }));
        }
      }
      if (PRINCIPAL_TO_REPORT_ROLE[data.role]) {
        const added = superviseeIds.filter((id) => !initialSuperviseeIds.includes(id));
        const removed = initialSuperviseeIds.filter((id) => !superviseeIds.includes(id));
        for (const id of added) {
          ops.push(updateUser.mutateAsync({ id, data: { principalId: editingUser.id } as any }));
        }
        for (const id of removed) {
          ops.push(updateUser.mutateAsync({ id, data: { principalId: null } as any }));
        }
      }
      if (ops.length > 0) {
        await Promise.all(ops);
        queryClient.invalidateQueries({ queryKey: getListUsersQueryKey() });
      }
    } catch {
      // Errors surfaced via individual mutation onError toasts.
    }
  };

  const watchedCreateRole = form.watch("role");
  const watchedEditRole = editForm.watch("role");

  const toggleStatus = (id: string, currentStatus: boolean) => {
    updateUser.mutate({ id, data: { isActive: !currentStatus } });
  };

  const handleExportCsv = () => {
    if (!users || users.length === 0) {
      toast({ variant: "destructive", title: "No data to export" });
      return;
    }
    downloadUsersCsv(users as UserRow[]);
    toast({ title: "CSV exported", description: `${users.length} users exported.` });
  };

  const hasAccess = canViewAllUsers(currentUser?.role);
  const isFullAdmin = canManageUsers(currentUser?.role);
  const pager = usePagination(users as UserRow[] | undefined);

  if (!hasAccess) {
    return (
      <EmptyState 
        title="Access Denied" 
        description="Only PMO Director, HR, and Site Admin can view personnel data." 
        icon={<ShieldAlert className="h-10 w-10 text-destructive/50" />} 
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Personnel</h1>
          <p className="text-muted-foreground">
            Manage user accounts and role assignments. This list covers personnel who
            participate in project delivery (PMs, consultants, sales, principals, admins,
            and supporting ops) — not the full company headcount.
          </p>
        </div>
        
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            className="gap-2"
            onClick={handleExportCsv}
            disabled={!users || users.length === 0}
            data-testid="button-export-csv"
          >
            <Download className="h-4 w-4" /> Export CSV
          </Button>

          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            {isFullAdmin && (
              <DialogTrigger asChild>
                <Button className="gap-2" data-testid="button-new-user">
                  <Plus className="h-4 w-4" /> New User
                </Button>
              </DialogTrigger>
            )}
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>Create New User</DialogTitle>
                <DialogDescription>Add a new personnel to the system.</DialogDescription>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 py-4">
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Full Name *</FormLabel>
                          <FormControl><Input placeholder="John Doe" {...field} /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email *</FormLabel>
                          <FormControl><Input type="email" placeholder="john@domain.com" {...field} /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Initial Password *</FormLabel>
                          <FormControl><Input type="password" {...field} /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="role"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>System Role *</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select a role" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {Object.entries(RoleLabels).map(([key, label]) => (
                                <SelectItem key={key} value={key}>{label}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Job Title</FormLabel>
                          <FormControl><Input placeholder="Senior Pentester" {...field} value={field.value || ""} /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="dailyRate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Daily Rate (IDR)</FormLabel>
                          <FormControl><Input type="number" placeholder="1500000" {...field} value={field.value || ""} /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  {watchedCreateRole === UserRole.PROJECT_MANAGER && (
                    <FormField
                      control={form.control}
                      name="managerId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>PMO Director</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value || NONE}>
                            <FormControl>
                              <SelectTrigger data-testid="select-create-manager">
                                <SelectValue placeholder="Select PMO Director" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value={NONE}>— Unassigned —</SelectItem>
                              {managers.map((m: any) => (
                                <SelectItem key={m.id} value={m.id}>{m.name}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="seniority"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Seniority</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value || NONE}>
                            <FormControl>
                              <SelectTrigger data-testid="select-create-seniority">
                                <SelectValue placeholder="—" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value={NONE}>— None —</SelectItem>
                              {SENIORITY_OPTIONS.map((s) => (
                                <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="businessUnitId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Business Unit</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value || NONE}>
                            <FormControl>
                              <SelectTrigger data-testid="select-create-bu">
                                <SelectValue placeholder="—" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value={NONE}>— None —</SelectItem>
                              {(businessUnits ?? []).filter((b: any) => b.isActive).map((b: any) => (
                                <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="text-sm font-medium text-foreground">Skills</div>
                    {!skillsCatalog?.length ? (
                      <p className="text-xs text-muted-foreground">No skills in the catalog yet.</p>
                    ) : (
                      <ScrollArea className="h-32 rounded-md border border-border p-2">
                        <div className="grid grid-cols-2 gap-1">
                          {(skillsCatalog ?? []).filter((s: any) => s.isActive).map((s: any) => {
                            const checked = createSkillIds.includes(s.id);
                            return (
                              <label key={s.id} className="flex items-center gap-2 text-xs">
                                <Checkbox
                                  checked={checked}
                                  onCheckedChange={(v) => {
                                    setCreateSkillIds((prev) =>
                                      v ? Array.from(new Set([...prev, s.id])) : prev.filter((id) => id !== s.id)
                                    );
                                  }}
                                  data-testid={`check-create-skill-${s.id}`}
                                />
                                <span>{s.name}</span>
                              </label>
                            );
                          })}
                        </div>
                      </ScrollArea>
                    )}
                  </div>

                  {PRINCIPAL_FOR_ROLE[watchedCreateRole] && (
                    <FormField
                      control={form.control}
                      name="principalId"
                      render={({ field }) => {
                        const pool = principalsByRole(watchedCreateRole);
                        return (
                          <FormItem>
                            <FormLabel>Principal Supervisor</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value || NONE}>
                              <FormControl>
                                <SelectTrigger data-testid="select-create-principal">
                                  <SelectValue placeholder="Select Principal" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value={NONE}>— Unassigned —</SelectItem>
                                {pool.map((p: any) => (
                                  <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        );
                      }}
                    />
                  )}
                  <DialogFooter className="pt-4">
                    <Button type="button" variant="outline" onClick={() => setIsCreateOpen(false)}>Cancel</Button>
                    <Button type="submit" disabled={createUser.isPending}>
                      {createUser.isPending ? "Creating..." : "Create User"}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {isLoading ? (
        <TableSkeleton columns={5} rows={8} />
      ) : !users?.length ? (
        <EmptyState title="No users found" description="No user accounts exist in the system." />
      ) : (
        <Card className="overflow-hidden border-border shadow-sm">
          <Table>
            <TableHeader className="bg-muted/50">
              <TableRow>
                <TableHead>User</TableHead>
                <TableHead>Role</TableHead>
                <TableHead className="text-right">Daily Rate</TableHead>
                <TableHead className="text-center">Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {pager.pageItems.map((u) => {
                const initials = u.name.split(" ").map(n => n[0]).join("").toUpperCase().substring(0, 2);
                return (
                  <TableRow key={u.id} className="group">
                    <TableCell>
                      <div className="flex items-center space-x-3">
                        <Avatar className="h-8 w-8 border border-border">
                          <AvatarFallback className="bg-primary/10 text-primary text-xs">{initials}</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium text-foreground">{u.name}</div>
                          <div className="text-xs text-muted-foreground">{u.email}</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-col space-y-1">
                        <Badge variant="outline" className="w-fit bg-secondary text-secondary-foreground border-border">
                          {RoleLabels[u.role]}
                        </Badge>
                        {u.title && <span className="text-xs text-muted-foreground">{u.title}</span>}
                      </div>
                    </TableCell>
                    <TableCell className="text-right font-mono text-sm">
                      {u.dailyRate ? formatIDR(u.dailyRate) : "-"}
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge variant="outline" className={u.isActive ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20" : "bg-destructive/10 text-destructive border-destructive/20"}>
                        {u.isActive ? "Active" : "Inactive"}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Link href={`/users/${u.id}`}>
                          <Button
                            variant="ghost"
                            size="sm"
                            data-testid={`button-view-projects-${u.id}`}
                          >
                            <Briefcase className="h-3.5 w-3.5 mr-1" /> Projects
                          </Button>
                        </Link>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setEditingUser(u as UserRow)}
                          data-testid={`button-edit-${u.id}`}
                        >
                          <Pencil className="h-3.5 w-3.5 mr-1" /> Edit
                        </Button>
                        {isFullAdmin && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => toggleStatus(u.id, u.isActive)}
                            className={u.isActive ? "text-destructive hover:text-destructive/80" : "text-emerald-500 hover:text-emerald-500/80"}
                            disabled={updateUser.isPending && updateUser.variables?.id === u.id}
                            data-testid={`button-toggle-${u.id}`}
                          >
                            {u.isActive ? "Deactivate" : "Activate"}
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
          <Pagination
            page={pager.page}
            pageSize={pager.pageSize}
            total={pager.total}
            totalPages={pager.totalPages}
            onPageChange={pager.setPage}
            onPageSizeChange={pager.setPageSize}
            testId="users-pagination"
          />
        </Card>
      )}

      <Dialog open={!!editingUser} onOpenChange={(open) => { if (!open) setEditingUser(null); }}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Edit User</DialogTitle>
            <DialogDescription>
              {editingUser ? `Update details for ${editingUser.email}. Email cannot be changed.` : ""}
            </DialogDescription>
          </DialogHeader>
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(onEditSubmit)} className="space-y-4 py-4">
              <FormField
                control={editForm.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Full Name *</FormLabel>
                    <FormControl><Input placeholder="John Doe" {...field} data-testid="input-edit-name" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-2 gap-4">
                {isFullAdmin ? (
                  <FormField
                    control={editForm.control}
                    name="role"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>System Role *</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger data-testid="select-edit-role">
                              <SelectValue placeholder="Select a role" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {Object.entries(RoleLabels).map(([key, label]) => (
                              <SelectItem key={key} value={key}>{label}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                ) : (
                  <FormItem>
                    <FormLabel>System Role</FormLabel>
                    <Input value={editingUser ? RoleLabels[editingUser.role] : ""} disabled />
                  </FormItem>
                )}
                <FormField
                  control={editForm.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Job Title</FormLabel>
                      <FormControl><Input placeholder="Senior Pentester" {...field} value={field.value || ""} data-testid="input-edit-title" /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={editForm.control}
                  name="dailyRate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Daily Rate (IDR)</FormLabel>
                      <FormControl><Input type="number" placeholder="1500000" {...field} value={field.value ?? ""} data-testid="input-edit-rate" /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                {isFullAdmin && (
                  <FormField
                    control={editForm.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Reset Password</FormLabel>
                        <FormControl><Input type="password" placeholder="Leave blank to keep" {...field} value={field.value || ""} data-testid="input-edit-password" /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={editForm.control}
                  name="seniority"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Seniority</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || NONE}>
                        <FormControl>
                          <SelectTrigger data-testid="select-edit-seniority">
                            <SelectValue placeholder="—" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value={NONE}>— None —</SelectItem>
                          {SENIORITY_OPTIONS.map((s) => (
                            <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={editForm.control}
                  name="businessUnitId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Business Unit</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || NONE}>
                        <FormControl>
                          <SelectTrigger data-testid="select-edit-bu">
                            <SelectValue placeholder="—" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value={NONE}>— None —</SelectItem>
                          {(businessUnits ?? []).filter((b: any) => b.isActive).map((b: any) => (
                            <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="space-y-2">
                <div className="text-sm font-medium text-foreground">Skills</div>
                {!skillsCatalog?.length ? (
                  <p className="text-xs text-muted-foreground">No skills in the catalog yet.</p>
                ) : (
                  <ScrollArea className="h-32 rounded-md border border-border p-2">
                    <div className="grid grid-cols-2 gap-1">
                      {(skillsCatalog ?? []).filter((s: any) => s.isActive).map((s: any) => {
                        const checked = editSkillIds.includes(s.id);
                        return (
                          <label key={s.id} className="flex items-center gap-2 text-xs">
                            <Checkbox
                              checked={checked}
                              onCheckedChange={(v) => {
                                setEditSkillIds((prev) =>
                                  v ? Array.from(new Set([...prev, s.id])) : prev.filter((id) => id !== s.id)
                                );
                              }}
                              data-testid={`check-edit-skill-${s.id}`}
                            />
                            <span>{s.name}</span>
                          </label>
                        );
                      })}
                    </div>
                  </ScrollArea>
                )}
              </div>

              {watchedEditRole === UserRole.PROJECT_MANAGER && (
                <FormField
                  control={editForm.control}
                  name="managerId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>PMO Director (this PM reports to)</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || NONE}>
                        <FormControl>
                          <SelectTrigger data-testid="select-edit-manager">
                            <SelectValue placeholder="Select PMO Director" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value={NONE}>— Unassigned —</SelectItem>
                          {managers.map((m: any) => (
                            <SelectItem key={m.id} value={m.id}>{m.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {PRINCIPAL_FOR_ROLE[watchedEditRole] && (
                <FormField
                  control={editForm.control}
                  name="principalId"
                  render={({ field }) => {
                    const pool = principalsByRole(watchedEditRole);
                    return (
                      <FormItem>
                        <FormLabel>Principal Supervisor</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value || NONE}>
                          <FormControl>
                            <SelectTrigger data-testid="select-edit-principal">
                              <SelectValue placeholder="Select Principal" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value={NONE}>— Unassigned —</SelectItem>
                            {pool.map((p: any) => (
                              <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    );
                  }}
                />
              )}

              {watchedEditRole === UserRole.MANAGEMENT && (() => {
                const allPms = ((users ?? []) as any[]).filter((u) => u.role === UserRole.PROJECT_MANAGER);
                return (
                  <div className="space-y-2">
                    <div className="text-sm font-medium text-foreground">
                      Project Managers under this PMO Director
                    </div>
                    {allPms.length === 0 ? (
                      <p className="text-sm text-muted-foreground">No PMs exist yet.</p>
                    ) : (
                      <ScrollArea className="h-40 rounded-md border border-border p-2">
                        <div className="space-y-2">
                          {allPms.map((pm) => {
                            const checked = reportPmIds.includes(pm.id);
                            const ownedByOther = !!pm.managerId && pm.managerId !== editingUser?.id;
                            return (
                              <label key={pm.id} className="flex items-center gap-2 text-sm">
                                <Checkbox
                                  checked={checked}
                                  onCheckedChange={(v) => {
                                    setReportPmIds((prev) =>
                                      v ? Array.from(new Set([...prev, pm.id])) : prev.filter((id) => id !== pm.id)
                                    );
                                  }}
                                  data-testid={`check-pm-${pm.id}`}
                                />
                                <span className="font-medium text-foreground">{pm.name}</span>
                                {ownedByOther && !checked && (
                                  <span className="text-xs text-muted-foreground">
                                    (currently reports to another PMO)
                                  </span>
                                )}
                              </label>
                            );
                          })}
                        </div>
                      </ScrollArea>
                    )}
                    <p className="text-xs text-muted-foreground">
                      Toggling a PM here reassigns their PMO Director.
                    </p>
                  </div>
                );
              })()}

              {isPrincipalRole(watchedEditRole) && (() => {
                const reportRole = PRINCIPAL_TO_REPORT_ROLE[watchedEditRole as UserRole];
                const pool = ((users ?? []) as any[]).filter((u) => u.role === reportRole);
                return (
                  <div className="space-y-2">
                    <div className="text-sm font-medium text-foreground">
                      Direct reports ({reportRole ? RoleLabels[reportRole] : ""})
                    </div>
                    {pool.length === 0 ? (
                      <p className="text-sm text-muted-foreground">No users to assign.</p>
                    ) : (
                      <ScrollArea className="h-40 rounded-md border border-border p-2">
                        <div className="space-y-2">
                          {pool.map((u) => {
                            const checked = superviseeIds.includes(u.id);
                            const ownedByOther = !!u.principalId && u.principalId !== editingUser?.id;
                            return (
                              <label key={u.id} className="flex items-center gap-2 text-sm">
                                <Checkbox
                                  checked={checked}
                                  onCheckedChange={(v) => {
                                    setSuperviseeIds((prev) =>
                                      v ? Array.from(new Set([...prev, u.id])) : prev.filter((id) => id !== u.id)
                                    );
                                  }}
                                  data-testid={`check-supervisee-${u.id}`}
                                />
                                <span className="font-medium text-foreground">{u.name}</span>
                                {ownedByOther && !checked && (
                                  <span className="text-xs text-muted-foreground">
                                    (currently reports to another Principal)
                                  </span>
                                )}
                              </label>
                            );
                          })}
                        </div>
                      </ScrollArea>
                    )}
                    <p className="text-xs text-muted-foreground">
                      Toggling a person here reassigns their Principal supervisor.
                    </p>
                  </div>
                );
              })()}

              <DialogFooter className="pt-4">
                <Button type="button" variant="outline" onClick={() => setEditingUser(null)}>Cancel</Button>
                <Button type="submit" disabled={editUserMutation.isPending} data-testid="button-save-edit">
                  {editUserMutation.isPending ? "Saving..." : "Save Changes"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
